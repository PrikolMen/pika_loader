FlexPoser.Preferences = {}
FlexPoser.Preferences.AutoCalibrate = true

FlexPoser.ApplyPreferences = function()
	-- Preferences can only be applied module-side if module is loaded
	if !FlexPoser.Status.Module then
		return
	end

	-- Apply image scale
	local scaleName = FlexPoser.Preferences.ImageScale
	if scaleName == "Full" then
		__SetImageScale(0);
	elseif scaleName == "Half (1/2)" then
		__SetImageScale(1);
	else
		__SetImageScale(2);
	end
		
	-- Apply tracking rate
	local fpsName = FlexPoser.Preferences.TrackingRate
	if fpsName == "High (30 FPS)" then
		__SetTrackingRate(0);
	elseif fpsName == "Medium (20 FPS)" then
		__SetTrackingRate(1);
	else
		__SetTrackingRate(2);
	end
end

FlexPoser.ReadPreferences = function()
	-- By default, use default preferences
	local autogen = true

	-- Attempt to load preferences from file
	local contents = file.Read( "flexposer_preferences.txt" )
	if contents != nil then
		-- Split file contents into lines
		local split_into_lines = function(str)
			local t = {}
			local function helper(line) table.insert(t, line) return "" end
			helper((str:gsub("(.-)\r?\n", helper)))
			return t
		end
		local lines = split_into_lines( contents )
	
		-- If enough lines, attempt to process them
		if table.getn( lines ) >= 14 then
			pcall( 
				function()
					FlexPoser.Preferences.AutoShow = tobool(lines[1])
					FlexPoser.Preferences.AutoConnect = tobool(lines[2])
					FlexPoser.Preferences.LastProfile = lines[3]
					FlexPoser.Preferences.ViewEnabled = tobool(lines[4])
					FlexPoser.Preferences.ViewSize = lines[5]
					FlexPoser.Preferences.ViewAnchor = lines[6]
					FlexPoser.Preferences.TrackRotation = tobool(lines[7])
					FlexPoser.Preferences.TrackPitch = tobool(lines[8])
					FlexPoser.Preferences.TrackYaw = tobool(lines[9])
					FlexPoser.Preferences.TrackRoll = tobool(lines[10])
					FlexPoser.Preferences.ImageScale = lines[11]
					FlexPoser.Preferences.TrackingRate = lines[12]
					FlexPoser.Preferences.AutoConnect = tobool(lines[13])
					FlexPoser.Preferences.AutoConnectIndex = tonumber(lines[14])
					autogen = false
				end 
			)
		end
	end
	
	if autogen then
		print( "Auto-generating preferences" )
	
		-- Use default preferences
		FlexPoser.Preferences.AutoShow = false
		FlexPoser.Preferences.AutoConnect = false
		FlexPoser.Preferences.LastProfile = ""
		FlexPoser.Preferences.ViewEnabled = false
		FlexPoser.Preferences.ViewSize = "Medium"
		FlexPoser.Preferences.ViewAnchor = "Top"
		FlexPoser.Preferences.TrackRotation = true
		FlexPoser.Preferences.TrackPitch = true
		FlexPoser.Preferences.TrackYaw = true
		FlexPoser.Preferences.TrackRoll = true
		FlexPoser.Preferences.ImageScale = "Full"
		FlexPoser.Preferences.TrackingRate = "Medium (20 FPS)"
		FlexPoser.Preferences.AutoConnect = false
		FlexPoser.Preferences.AutoConnectIndex = 0
	end
end

FlexPoser.WritePreferences = function()
	-- Format all preferences for writing
	local values = {
		tostring(FlexPoser.Preferences.AutoShow),
		tostring(FlexPoser.Preferences.AutoConnect),
		tostring(FlexPoser.Preferences.LastProfile),
		tostring(FlexPoser.Preferences.ViewEnabled),
		tostring(FlexPoser.Preferences.ViewSize),
		tostring(FlexPoser.Preferences.ViewAnchor),
		tostring(FlexPoser.Preferences.TrackRotation),
		tostring(FlexPoser.Preferences.TrackPitch),
		tostring(FlexPoser.Preferences.TrackYaw),
		tostring(FlexPoser.Preferences.TrackRoll),
		tostring(FlexPoser.Preferences.ImageScale),
		tostring(FlexPoser.Preferences.TrackingRate),
		tostring(FlexPoser.Preferences.AutoConnect),
		tostring(FlexPoser.Preferences.AutoConnectIndex),
		""
	}
	local contents = table.concat(values, "\n")
	
	-- Write preferences to file
	file.Write( "flexposer_preferences.txt", contents )
end