FlexPoser.ApplyWeights = function( ent, weights, bPlayer )
	-- Eyes
	ent:SetFlexWeight(0, weights[ FlexPoser.Constants.LeftEyeOpener ])
	ent:SetFlexWeight(1, weights[ FlexPoser.Constants.RightEyeOpener ])
	ent:SetFlexWeight(6, weights[ FlexPoser.Constants.LeftEyeOpener ])
	ent:SetFlexWeight(7, weights[ FlexPoser.Constants.RightEyeOpener ])
	
	-- Brows
	ent:SetFlexWeight(10, weights[ FlexPoser.Constants.LeftInnerBrowRaiser ])
	ent:SetFlexWeight(11, weights[ FlexPoser.Constants.RightInnerBrowRaiser ])
	ent:SetFlexWeight(12, weights[ FlexPoser.Constants.LeftOuterBrowRaiser ])
	ent:SetFlexWeight(13, weights[ FlexPoser.Constants.RightOuterBrowRaiser ])
	ent:SetFlexWeight(14, weights[ FlexPoser.Constants.LeftBrowLowerer ])
	ent:SetFlexWeight(15, weights[ FlexPoser.Constants.RightBrowLowerer ])

	-- Mouth stretch
	ent:SetFlexWeight(22, 0.8 * weights[ FlexPoser.Constants.LeftMouthPuller ])
	ent:SetFlexWeight(23, 0.8 * weights[ FlexPoser.Constants.RightMouthPuller ])
	
	-- Mouth part
	ent:SetFlexWeight(39, weights[ FlexPoser.Constants.LeftMouthParter ])
	ent:SetFlexWeight(40, weights[ FlexPoser.Constants.RightMouthParter ])
	ent:SetFlexWeight(41, weights[ FlexPoser.Constants.LeftMouthParter ])
	ent:SetFlexWeight(42, weights[ FlexPoser.Constants.RightMouthParter ])
	
	-- Mouth pucker
	local puckerScale = 1
	if bPlayer then
		puckerScale = 0.6
	end
	ent:SetFlexWeight(29, puckerScale * weights[ FlexPoser.Constants.LeftMouthPuckerer ])
	ent:SetFlexWeight(30, puckerScale * weights[ FlexPoser.Constants.RightMouthPuckerer ])

	-- Jaw drop
	ent:SetFlexWeight(39, weights[ FlexPoser.Constants.JawDrop ])
	
	-- Attempt to fix Alyx and Gman weird mouths
	if (ent:GetModel() == "models/player/gman_high.mdl" || ent:GetModel() == "models/player/alyx.mdl") then
		if bPlayer then
			ent:SetFlexWeight( 47, 0.5 )
			ent:SetFlexWeight( 48, 0.5 )
		else
			ent:SetFlexWeight( 47, 0.25 )
			ent:SetFlexWeight( 48, 0.25 )
		end
	end
end

FlexPoser.ApplyGlobals = function( ent, globals, bPlayer )
	local maximumRotation = 30
	for i=2,4 do
		globals[i] = math.Clamp( globals[i], -maximumRotation, maximumRotation )
	end

	local headBoneID = ent:LookupBone( "ValveBiped.Bip01_Head1" )
	if headBoneID then
		local headAngle = Angle( globals[4], globals[2], globals[3] )
		ent:ManipulateBoneAngles( headBoneID, headAngle )
	end
end