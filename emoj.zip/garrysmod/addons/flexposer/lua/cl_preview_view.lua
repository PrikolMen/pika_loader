FlexPoser.Preview.SetStatusMessage = function( msg, colName )
	FlexPoser.Preview.Label:SetText( msg )
	FlexPoser.Preview.Label:SizeToContents()
	--FlexPoser.Preview.Label:CenterHorizontal()
	
	if colName == "red" then
		FlexPoser.Preview.Label:SetColor( Color( 200, 50, 50, 255) )
	elseif colName == "green" then
		FlexPoser.Preview.Label:SetColor( Color( 50, 200, 50, 255) )
	end
end

FlexPoser.Preview.Reposition = function()
	FlexPoser.Preview.Container:SetVisible( FlexPoser.Preferences.ViewEnabled )

	local ViewSize = 10
	if FlexPoser.Preferences.ViewSize == "Medium" then
		ViewSize = 128
	elseif FlexPoser.Preferences.ViewSize == "Large" then
		ViewSize = 192
	elseif FlexPoser.Preferences.ViewSize == "Very large" then
		ViewSize = 256
	end
	
	local ContainerSize = ViewSize + 12
	FlexPoser.Preview.Container:SetSize( ContainerSize, ContainerSize )
	FlexPoser.Preview.Label:SetPos( 10, ContainerSize - 30 )
	FlexPoser.Preview.ModelPanel:SetSize( ViewSize, ViewSize )
	
	local Margin = 20
	local PosX = Margin
	local PosY = Margin
	if FlexPoser.Preferences.ViewAnchor == "Left" then
		PosX = Margin
		PosY = ScrH() / 2 - ContainerSize / 2
	elseif FlexPoser.Preferences.ViewAnchor == "Top left" then
		PosX = Margin
		PosY = Margin
	elseif FlexPoser.Preferences.ViewAnchor == "Top" then
		PosX = ScrW() / 2 - ContainerSize / 2
		PosY = Margin
	elseif FlexPoser.Preferences.ViewAnchor == "Top right" then
		PosX = ScrW() - Margin - ContainerSize
		PosY = Margin
	elseif FlexPoser.Preferences.ViewAnchor == "Right" then
		PosX = ScrW() - Margin - ContainerSize
		PosY = ScrH() / 2 - ContainerSize / 2
	elseif FlexPoser.Preferences.ViewAnchor == "Bottom left" then
		PosX = Margin
		PosY = ScrH() - Margin - ContainerSize
	elseif FlexPoser.Preferences.ViewAnchor == "Bottom" then
		PosX = ScrW() / 2 - ContainerSize / 2
		PosY = ScrH() - Margin - ContainerSize
	elseif FlexPoser.Preferences.ViewAnchor == "Bottom right" then
		PosX = ScrW() - Margin - ContainerSize
		PosY = ScrH() - Margin - ContainerSize
	end
	FlexPoser.Preview.Container:SetPos( PosX, PosY )
end