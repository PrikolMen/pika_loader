FlexPoser.Wizard.NameCancelHandler = function()
	FlexPoser.Wizard.NameEntry.Frame:SetVisible( false )
end

FlexPoser.Wizard.NameEnteredHandler = function()
	local name = FlexPoser.Wizard.NameEntry.Field:GetValue()
	local numChars = string.len(name)
	local maxChars = FlexPoser.Wizard.NameEntry.MaxChars
	if numChars <= 0 then
		Derma_Message( "Please enter a name.", "", "OK" )
	elseif numChars > maxChars then
		Derma_Message( "Your name may not contain more than " .. maxChars .. " characters.", "", "OK" )
	elseif FlexPoser.Profiles[name] != nil then
		Derma_Message( "A profile with that name already exists.", "", "OK" )
	else
		FlexPoser.Wizard.NameEntry.Frame:SetVisible( false )
		FlexPoser.Wizard.Open( name, false )
	end
end

FlexPoser.Wizard.StoreNeutral = function( dists, firstID, lastID )
	for i=firstID,lastID do
		FlexPoser.Wizard.Process.Neutral[i] = dists[i]
	end
end

FlexPoser.Wizard.StoreMax = function( value, firstID, lastID )
	for i=firstID,lastID do
		FlexPoser.Wizard.Process.Maxima[i] = value
	end
end

FlexPoser.Wizard.CalibrationPoller = function()
	local PageID = FlexPoser.Wizard.PageID
	
	-- Safe guard: Remove poller when on wrong page
	if PageID < 4 || PageID > 9 then
		__StopMinMax()
		hook.Remove( "Think", "FC_PollCalibrate" )
		return
	end
	
	local RelaxationScale = 1
	local TryingTime = RealTime() - FlexPoser.Wizard.StartTrack
	if TryingTime > 2 then
		local OverTime = TryingTime - 2
		RelaxationScale = 1 - 0.3 * OverTime
	end
	
	-- Check if current expression satisfies gesture
	local InstructionID = PageID - 3
	local dL = 0
	local dR = 0
	local statusGreen = false
	
	if __IsFaceDetected() then
		FlexPoser.Wizard.Pages[PageID].StatusIcon:SetImage( "materials/status_success.png" )
		local dists = { __GetDistances() }
		local neutrals = FlexPoser.Wizard.Process.Neutral
	
		if InstructionID == 1 then
			-- Eyes open
			dL = dists[1] - neutrals[1]
			dR = dists[2] - neutrals[2]
			statusGreen = dL > 0.07 * RelaxationScale && dR > 0.07 * RelaxationScale
		elseif InstructionID == 2 then
			-- Brows lowered
			dL = dists[7] - neutrals[8]
			dR = dists[7] - neutrals[8]
			statusGreen = dL < -0.2 * RelaxationScale && dR < -0.2 * RelaxationScale
		elseif InstructionID == 3 then
			-- Brows raised
			dL = dists[3] - neutrals[3]
			dR = dists[4] - neutrals[4]
			statusGreen = dL > 0.5 * RelaxationScale && dR > 0.5 * RelaxationScale
		elseif InstructionID == 4 then
			-- Mouth pulled
			dL = dists[9] - neutrals[9]
			dR = dists[10] - neutrals[10]
			statusGreen = dL > 0.5 * RelaxationScale && dR > 0.5 * RelaxationScale
		elseif InstructionID == 5 then
			-- Mouth pucker
			dL = dists[13] - neutrals[13]
			dR = dists[14] - neutrals[14]
			statusGreen = dL < -0.5 * RelaxationScale && dR < -0.5 * RelaxationScale
		elseif InstructionID == 6 then
			-- Mouth part
			dL = dists[11] - neutrals[11]
			dR = dists[12] - neutrals[12]
			statusGreen = dL > 0.5 * RelaxationScale && dR > 0.5 * RelaxationScale
		end
	else
		FlexPoser.Wizard.Pages[PageID].StatusIcon:SetImage( "materials/status_failure.png" )
	end
	
	-- Check status green duration
	if statusGreen then
		FlexPoser.Wizard.Pages[PageID].StatusIcon2:SetImage( "materials/status_success.png" )
		
		local TimeGreen = RealTime() - FlexPoser.Wizard.StartGreen
		
		-- If green long enough, store results
		local minima = { __GetMinima() }
		local maxima = { __GetMaxima() }
		if TimeGreen > 1 then
			if InstructionID == 1 then
				-- Eyes open
				FlexPoser.Wizard.StoreMax( 0.5 * (maxima[1] + maxima[2]), 1, 2 )
			elseif InstructionID == 2 then
				-- Brows lowered
				FlexPoser.Wizard.StoreMax( 0.5 * (minima[7] + minima[8]), 7, 8 )
			elseif InstructionID == 3 then
				-- Brows raised
				FlexPoser.Wizard.StoreMax( 0.5 * (maxima[3] + maxima[4]), 3, 4 )
				FlexPoser.Wizard.StoreMax( 0.5 * (maxima[5] + maxima[6]), 5, 6 )
			elseif InstructionID == 4 then
				-- Mouth pulled
				FlexPoser.Wizard.StoreMax( 0.5 * (maxima[9] + maxima[10]), 9, 10 )
			elseif InstructionID == 5 then
				-- Mouth puckered
				FlexPoser.Wizard.StoreMax( 0.5 * (minima[13] + minima[14]), 13, 14 )
			elseif InstructionID == 6 then
				-- Mouth parted, jaw dropped
				FlexPoser.Wizard.StoreMax( 0.5 * (maxima[11] + maxima[12]), 11, 12 )
				FlexPoser.Wizard.StoreMax( maxima[15], 15, 15 )
			end
		
			surface.PlaySound( "ping.wav" )
			FlexPoser.Wizard.NextHandler()
		end
	else
		FlexPoser.Wizard.Pages[PageID].StatusIcon2:SetImage( "materials/status_failure.png" )
		FlexPoser.Wizard.StartGreen = RealTime()
	end
end

FlexPoser.Wizard.EnterPageCallback = function( PageID )
	if PageID >= 4 && PageID <= 9 then
		if FlexPoser.Preferences.AutoCalibrate then
			FlexPoser.Wizard.StartTrack = RealTime()
			FlexPoser.Wizard.StartGreen = RealTime()
			hook.Add( "Think", "FC_PollCalibrate", FlexPoser.Wizard.CalibrationPoller )
			__RestartMinMax()
		end
	end
end

-- Called when a page is exited using the next button
FlexPoser.Wizard.ExitPageCallback = function( PageID )
	if PageID == 1 then
		
	elseif PageID == 2 then
		-- Store neutral pose and certain minima
		surface.PlaySound( "shutter_click.wav" )
		local dists = { __GetDistances() }
		FlexPoser.Wizard.StoreNeutral( dists, 1, 15 )
		FlexPoser.Wizard.Process.Global = { __GetGlobals() }
		
	elseif PageID >= 4 && PageID <= 9 then
		if FlexPoser.Preferences.AutoCalibrate then
			-- Auto detected and stored stats, remove callback
			__StopMinMax()
			hook.Remove( "Think", "FC_PollCalibrate" )
		else
			-- Manually clicked next, store the stats
			local InstructionID = PageID - 3
			
			local dists = { __GetDistances() }
			if InstructionID == 1 then
				-- Eyes open
				FlexPoser.Wizard.StoreMax( dists, 1, 2 )
			elseif InstructionID == 2 then
				-- Brows lowered
				FlexPoser.Wizard.StoreMax( dists, 7, 8 )
			elseif InstructionID == 3 then
				-- Brows raised
				FlexPoser.Wizard.StoreMax( dists, 3, 6 )
			elseif InstructionID == 4 then
				-- Mouth pulled
				FlexPoser.Wizard.StoreMax( dists, 9, 10 )
			elseif InstructionID == 5 then
				-- Mouth puckered
				FlexPoser.Wizard.StoreMax( dists, 13, 14 )
			elseif InstructionID == 6 then
				-- Mouth part
				FlexPoser.Wizard.StoreMax( dists, 11, 12 )
				FlexPoser.Wizard.StoreMax( dists, 15, 15 )
			end
		end
	end
	
	if PageID == 9 then
		-- Retrieve profile name
		local Name = FlexPoser.Wizard.Process.Name
	
		-- Create profile if it doesn't exist
		if FlexPoser.Profiles[Name] == nil then
			FlexPoser.Profiles[Name] = {}
			FlexPoser.Profiles[Name].Neutral = {}
			FlexPoser.Profiles[Name].Maxima = {}
			FlexPoser.Profiles[Name].Global = {}
		end
		
		-- Copy calibration data into profile
		for i=1,FlexPoser.Constants.NumAUs do
			FlexPoser.Profiles[Name].Neutral[i] = FlexPoser.Wizard.Process.Neutral[i]
			FlexPoser.Profiles[Name].Maxima[i] = FlexPoser.Wizard.Process.Maxima[i]
		end
		for i=1,6 do
			FlexPoser.Profiles[Name].Global[i] = FlexPoser.Wizard.Process.Global[i]
		end
		
		-- Save profiles to file
		FlexPoser.WriteProfiles()
		
		-- Update GUI elements
		FlexPoser.Status.Profile = true
		FlexPoser.Status.ProfileName = Name
		FlexPoser.UpdateStatus()
	end
end