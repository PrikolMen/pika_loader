-- ===========================
--   GENERAL GUI
-- ===========================

-- Removes current panel and adds new panel by name
FlexPoser.Menu.SetStatusPanel = function( PanelName )
	FlexPoser.Menu.Panel:SetVisible( false )
	FlexPoser.Menu.Panel = FlexPoser.Menu.Panels[ PanelName ]
	FlexPoser.Menu.Panel:SetVisible( true )
end

FlexPoser.Menu.ShowError = function( msg, msg2 )
	FlexPoser.Menu.Panels[ "Error" ].InfoLabel:SetText( msg )
	FlexPoser.Menu.SetStatusPanel( "Error" )
	FlexPoser.Preview.SetStatusMessage( msg2, "red" )
	
	FlexPoser.Menu.Frame:SetVisible( true )
	FlexPoser.Menu.Frame:MakePopup()
end


-- ===========================
--   GENERAL BUTTONS
-- ===========================
FlexPoser.Menu.EnableButtonHandler = function()
	-- Toggle value and update button text
	FlexPoser.Status.Enabled = !FlexPoser.Status.Enabled
	if FlexPoser.Status.Enabled then
		FlexPoser.Menu.EnableButton:SetText( "Disable" )
	else
		FlexPoser.Menu.EnableButton:SetText( "Enable" )
	end
	
	-- If just enabled, try to load module and connect to webcam
	if FlexPoser.Status.Enabled then
		FlexPoser.TryEnable()
	else
		__StopTracking()
		if !FlexPoser.Preferences.AutoConnect then
			FlexPoser.Status.Webcam = false
		end
	end
	
	-- Update GUI
	FlexPoser.UpdateStatus()
end

-- Try to load module and connect to webcam
FlexPoser.Menu.RetryHandler = function()
	FlexPoser.TryEnable()
	FlexPoser.UpdateStatus()
end

-- ===========================
--   WEBCAM SELECTION PANEL
-- ===========================
FlexPoser.Menu.UseWebcamHandler = function()
	if FlexPoser.Preferences.AutoConnect then
		FlexPoser.Preferences.AutoConnectIndex = FlexPoser.Menu.WebcamComboIndex
	end

	FlexPoser.Menu.Panels[ "Webcam" ].ErrorLabel:SetVisible( false )
	local result, errorMsg = FlexPoser.TryConnect( FlexPoser.Menu.WebcamComboIndex )
	if result then
		FlexPoser.UpdateStatus()
	else
		FlexPoser.Menu.Panels[ "Webcam" ].ErrorLabel:SetVisible( true )
	end
end

FlexPoser.Menu.RefreshDevicesHandler = function()
	local ans = { __GetWebcamList() }
	local numCams = ans[1]
	
	if numCams == 0 then
		FlexPoser.Menu.Panels["Webcam"].FoundLabel:SetText( "Please select a webcam.\nFound no devices. Try anyway?" )
	elseif numCams == 1 then
		FlexPoser.Menu.Panels["Webcam"].FoundLabel:SetText( "Please select a webcam.\nFound 1 device." )
	else
		FlexPoser.Menu.Panels["Webcam"].FoundLabel:SetText( "Please select a webcam.\nFound " .. numCams .. " devices." )
	end
	
	
	FlexPoser.Menu.WebcamComboBox:Clear()
	
	if numCams > 0 then
		-- Add names
		for i=2, numCams + 1 do
			FlexPoser.Menu.WebcamComboBox:AddChoice( ans[i] )
		end
	
		-- Select first name
		FlexPoser.Menu.WebcamComboBox:SetValue( ans[2] )
		FlexPoser.Menu.WebcamComboIndex = 0
	else
		-- Add default names
		for i=0,4 do
			FlexPoser.Menu.WebcamComboBox:AddChoice( "Try device " .. i )
		end
		
		-- Select first name
		FlexPoser.Menu.WebcamComboBox:SetValue( "Try device 0" )
		FlexPoser.Menu.WebcamComboIndex = 0
	end
end

-- ===========================
--   PROFILE SELECTION PANEL
-- ===========================
FlexPoser.Menu.RefreshProfilesHandler = function()
	-- Update profile panel combo box
	local names={}
	local n=0

	for k,v in pairs(FlexPoser.Profiles) do
	  n=n+1
	  names[n]=k
	end
	
	FlexPoser.Menu.ProfileComboBox:Clear()
	local NameSet = false
	for i=1,table.getn(names) do
		FlexPoser.Menu.ProfileComboBox:AddChoice( names[i] )
		if !NameSet || names[i] == FlexPoser.Preferences.LastProfile then
			FlexPoser.Menu.ProfileComboBox:SetValue( names[i] )
			FlexPoser.Menu.ProfileComboSelection = names[i]
			NameSet = true
		end
	end
end

-- Opens profile setup menu
FlexPoser.Menu.CreateProfileHandler = function()
	FlexPoser.Wizard.NameEntry.Field:SetValue( "" )
	FlexPoser.Wizard.NameEntry.Field:SetText( "" )
	FlexPoser.Wizard.NameEntry.Frame:SetVisible( true )
	FlexPoser.Wizard.NameEntry.Frame:MakePopup()
end

-- Load selected profile
FlexPoser.Menu.LoadProfileHandler = function()
	local selectedName = FlexPoser.Menu.ProfileComboSelection
	--print( "Loading " .. selectedName )
	if FlexPoser.Profiles[selectedName] != nil then
		FlexPoser.Status.Profile = true
		FlexPoser.Status.ProfileName = selectedName
		FlexPoser.UpdateStatus()
	end
end

-- Delete selected profile
FlexPoser.Menu.DeleteProfileHandler = function()
	local selectedName = FlexPoser.Menu.ProfileComboSelection
	--print( "Deleting " .. selectedName )
	if FlexPoser.Profiles[selectedName] != nil then
		FlexPoser.Profiles[selectedName] = nil
	end
	FlexPoser.UpdateStatus()
end

-- ===========================
--   RUNNING PANEL
-- ===========================

-- Unselects current camera
FlexPoser.Menu.SwitchWebcamHandler = function()
	__StopTracking()
	FlexPoser.Status.Webcam = false
	FlexPoser.UpdateStatus()
	
	FlexPoser.Preferences.AutoConnect = false
	FlexPoser.WritePreferences()
	FlexPoser.Menu.Panels["Webcam"].AutoConnectBox:SetChecked( false )
end

-- Unloads profile and goes to profile management
FlexPoser.Menu.SwitchProfileHandler = function()
	FlexPoser.Status.Profile = false
	FlexPoser.UpdateStatus()
end

-- Opens profile setup menu, using current profile
FlexPoser.Menu.RecalibrateHandler = function()
	FlexPoser.Wizard.Open( FlexPoser.Status.ProfileName, true )
end

-- Unloads profile and goes to profile management
FlexPoser.Menu.CenterHeadHandler = function()
	local globals = { __GetGlobals() }
	local activeProfile = FlexPoser.Status.ProfileName
	for i=1, 6 do
		FlexPoser.Profiles[activeProfile].Global[i] = globals[i]
	end
	FlexPoser.WriteProfiles()
end