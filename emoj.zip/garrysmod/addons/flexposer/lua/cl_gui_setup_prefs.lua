FlexPoser.Menu.CreatePreferencesPanel = function()
	local sepY1 = 70
	local sepY2 = 210
	local sepY3 = 325
	local sepY4 = 440
	local spacing = 5
	local marginX = 10
	local marginY = 26
	
	local QPanel = vgui.Create( "DPanel" )
	QPanel:SetPaintBackground( false )
	
	-- AUTO CONNECT OPTIONS	
	local APanel = vgui.Create( "DPanel", QPanel )
	APanel:SetPos( 0, 0 )
	APanel:SetSize( 256, sepY1 )
	
	local catLabel1 = vgui.Create( "DLabel", APanel )
	catLabel1:SetPos( marginX, 6 )
	catLabel1:SetText( "General" )
	catLabel1:SetTextColor( Color(120, 120, 120, 255) )
	catLabel1:SizeToContents()
	
	local autoShowBox = vgui.Create( "DCheckBoxLabel", APanel )
	autoShowBox:SetPos( marginX, marginY )
	autoShowBox:SetChecked( FlexPoser.Preferences.AutoShow )
	autoShowBox:SetText( "Open this window when joining" )
	autoShowBox:SetTextColor( Color(0, 0, 0, 255) )
	autoShowBox:SizeToContents()
	autoShowBox.OnChange = function()
		FlexPoser.Preferences.AutoShow = autoShowBox:GetChecked()
		FlexPoser.WritePreferences()
	end
	
	local autoCheckBox = vgui.Create( "DCheckBoxLabel", APanel )
	autoCheckBox:SetPos( marginX, marginY + 20 )
	autoCheckBox:SetChecked( FlexPoser.Preferences.AutoConnect )
	autoCheckBox:SetText( "Auto-enable FlexPoser when joining" )
	autoCheckBox:SetTextColor( Color(0, 0, 0, 255) )
	autoCheckBox:SizeToContents()
	autoCheckBox.OnChange = function()
		FlexPoser.Preferences.AutoConnect = autoCheckBox:GetChecked()
		FlexPoser.WritePreferences()
	end
	
	-- PREVIEW OPTIONS
	local PPanel = vgui.Create( "DPanel", QPanel )
	PPanel:SetPos( 0, sepY1 + spacing )
	PPanel:SetSize( 256, sepY2 - sepY1 - spacing )
	
	local catLabel2 = vgui.Create( "DLabel", PPanel )
	catLabel2:SetPos( marginX, 6 )
	catLabel2:SetText( "Preview" )
	catLabel2:SetTextColor( Color(120, 120, 120, 255) )
	catLabel2:SizeToContents()
	
	-- Preview check box
	local previewCheckBox = vgui.Create( "DCheckBoxLabel", PPanel )
	previewCheckBox:SetPos( marginX, marginY )
	previewCheckBox:SetChecked( FlexPoser.Preferences.ViewEnabled )
	previewCheckBox:SetText( "Show preview panel" )
	previewCheckBox:SetTextColor( Color(0, 0, 0, 255) )
	previewCheckBox:SizeToContents()
	previewCheckBox.OnChange = function()
		FlexPoser.Preferences.ViewEnabled = previewCheckBox:GetChecked()
		FlexPoser.Preview.Reposition()
		FlexPoser.WritePreferences()
	end
	
	-- Position combo box
	local anchorLabel = vgui.Create( "DLabel", PPanel )
	anchorLabel:SetPos( marginX, marginY + 20 )
	anchorLabel:SetText( "Panel position: " )
	anchorLabel:SetTextColor( Color(0, 0, 0, 255) )
	anchorLabel:SizeToContents()
	
	local anchorBox = vgui.Create( "DComboBox", PPanel )
	anchorBox:SetPos( marginX, marginY + 36 )
	anchorBox:SetSize( 200, 20 )
	anchorBox:AddChoice( "Left" )
	anchorBox:AddChoice( "Right" )
	anchorBox:AddChoice( "Bottom" )
	anchorBox:AddChoice( "Top" )
	anchorBox:AddChoice( "Top left" )
	anchorBox:AddChoice( "Top right" )
	anchorBox:AddChoice( "Bottom left" )
	anchorBox:AddChoice( "Bottom right" )
	anchorBox:SetValue( FlexPoser.Preferences.ViewAnchor )
	anchorBox.OnSelect = function( panel, index, value, data) 
		FlexPoser.Preferences.ViewAnchor = value
		FlexPoser.Preview.Reposition()
		FlexPoser.WritePreferences()
	end
	
	-- Size combo box
	local sizeLabel = vgui.Create( "DLabel", PPanel )
	sizeLabel:SetPos( marginX, marginY + 60 )
	sizeLabel:SetText( "Panel size: " )
	sizeLabel:SetTextColor( Color(0, 0, 0, 255) )
	sizeLabel:SizeToContents()
	
	local sizeBox = vgui.Create( "DComboBox", PPanel )
	sizeBox:SetPos( marginX, marginY + 76 )
	sizeBox:SetSize( 200, 20 )
	sizeBox:AddChoice( "Medium" )
	sizeBox:AddChoice( "Large" )
	sizeBox:AddChoice( "Very large" )
	sizeBox:SetValue( FlexPoser.Preferences.ViewSize )
	sizeBox.OnSelect = function( panel, index, value, data)
		FlexPoser.Preferences.ViewSize = value
		FlexPoser.Preview.Reposition()
		FlexPoser.WritePreferences()
	end
	
	-- TRACKING OPTIONS
	local TPanel = vgui.Create( "DPanel", QPanel )
	TPanel:SetPos( 0, sepY2 + spacing )
	TPanel:SetSize( 256, sepY3 - sepY2 - spacing )
	
	local catLabel3 = vgui.Create( "DLabel", TPanel )
	catLabel3:SetPos( marginX, 6 )
	catLabel3:SetText( "Head rotation" )
	catLabel3:SetTextColor( Color(120, 120, 120, 255) )
	catLabel3:SizeToContents()
	
	-- Track rotation check box
	local rotationCheckBox = vgui.Create( "DCheckBoxLabel", TPanel )
	rotationCheckBox:SetPos( marginX, marginY )
	rotationCheckBox:SetChecked( FlexPoser.Preferences.TrackRotation )
	rotationCheckBox:SetText( "Track head rotation" )
	rotationCheckBox:SetTextColor( Color(0, 0, 0, 255) )
	rotationCheckBox:SizeToContents()
	rotationCheckBox.OnChange = function()
		FlexPoser.Preferences.TrackRotation = rotationCheckBox:GetChecked()
		FlexPoser.WritePreferences()
	end
	
	-- Track rotation check box
	local pitchCheckBox = vgui.Create( "DCheckBoxLabel", TPanel )
	pitchCheckBox:SetPos( marginX + 20, marginY + 20 )
	pitchCheckBox:SetChecked( FlexPoser.Preferences.TrackPitch )
	pitchCheckBox:SetText( "Pitch" )
	pitchCheckBox:SetTextColor( Color(0, 0, 0, 255) )
	pitchCheckBox:SizeToContents()
	pitchCheckBox.OnChange = function()
		FlexPoser.Preferences.TrackPitch = pitchCheckBox:GetChecked()
		FlexPoser.WritePreferences()
	end
	
	-- Track rotation check box
	local yawCheckBox = vgui.Create( "DCheckBoxLabel", TPanel )
	yawCheckBox:SetPos( marginX + 20, marginY + 40 )
	yawCheckBox:SetChecked( FlexPoser.Preferences.TrackYaw )
	yawCheckBox:SetText( "Yaw" )
	yawCheckBox:SetTextColor( Color(0, 0, 0, 255) )
	yawCheckBox:SizeToContents()
	yawCheckBox.OnChange = function()
		FlexPoser.Preferences.TrackYaw = yawCheckBox:GetChecked()
		FlexPoser.WritePreferences()
	end
	
	-- Track roll check box
	local rollCheckBox = vgui.Create( "DCheckBoxLabel", TPanel )
	rollCheckBox:SetPos( marginX + 20, marginY + 60 )
	rollCheckBox:SetChecked( FlexPoser.Preferences.TrackRoll )
	rollCheckBox:SetText( "Roll" )
	rollCheckBox:SetTextColor( Color(0, 0, 0, 255) )
	rollCheckBox:SizeToContents()
	rollCheckBox.OnChange = function()
		FlexPoser.Preferences.TrackRoll = rollCheckBox:GetChecked()
		FlexPoser.WritePreferences()
	end
	
	-- PERFORMANCE OPTIONS
	local OPanel = vgui.Create( "DPanel", QPanel )
	OPanel:SetPos( 0, sepY3 + spacing )
	OPanel:SetSize( 256, sepY4 - sepY3 - spacing )
	
	local catLabel4 = vgui.Create( "DLabel", OPanel )
	catLabel4:SetPos( marginX, 6 )
	catLabel4:SetText( "Performance options" )
	catLabel4:SetTextColor( Color(120, 120, 120, 255) )
	catLabel4:SizeToContents()
	
	-- Image scale combo box
	local scaleLabel = vgui.Create( "DLabel", OPanel )
	scaleLabel:SetPos( marginX, marginY )
	scaleLabel:SetText( "Webcam image scaling: " )
	scaleLabel:SetTextColor( Color(0, 0, 0, 255) )
	scaleLabel:SizeToContents()
	
	local scaleBox = vgui.Create( "DComboBox", OPanel )
	scaleBox:SetPos( marginX, marginY + 16 )
	scaleBox:SetSize( 200, 20 )
	scaleBox:AddChoice( "Full" )
	scaleBox:AddChoice( "Half (1/2)" )
	scaleBox:AddChoice( "Quarter (1/4)" )
	scaleBox:SetValue( FlexPoser.Preferences.ImageScale )
	scaleBox.OnSelect = function( panel, index, value, data) 
		FlexPoser.Preferences.ImageScale = value
		FlexPoser.ApplyPreferences()
		FlexPoser.WritePreferences()
	end
	
	-- Tracking rate combo box
	local fpsLabel = vgui.Create( "DLabel", OPanel )
	fpsLabel:SetPos( marginX, marginY + 40 )
	fpsLabel:SetText( "Tracking rate: " )
	fpsLabel:SetTextColor( Color(0, 0, 0, 255) )
	fpsLabel:SizeToContents()
	
	local fpsBox = vgui.Create( "DComboBox", OPanel )
	fpsBox:SetPos( marginX, marginY + 56 )
	fpsBox:SetSize( 200, 20 )
	fpsBox:AddChoice( "High (30 FPS)" )
	fpsBox:AddChoice( "Medium (20 FPS)" )
	fpsBox:AddChoice( "Low (10 FPS)" )
	fpsBox:SetValue( FlexPoser.Preferences.TrackingRate )
	fpsBox.OnSelect = function( panel, index, value, data)
		FlexPoser.Preferences.TrackingRate = value
		FlexPoser.ApplyPreferences()
		FlexPoser.WritePreferences()
	end
	
	QPanel:SizeToContents()
	return QPanel
end