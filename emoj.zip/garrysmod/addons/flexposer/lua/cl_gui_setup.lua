FlexPoser.Menu = {}

FlexPoser.Menu.Create = function()
	-- Create the main GUI
	local MenuFrame = vgui.Create( "DFrame" )
	MenuFrame:SetPos( 20, 20 )
	MenuFrame:SetSize( 268, 548 )
	MenuFrame:SetTitle( "FlexPoser" )
	MenuFrame:SetDraggable( true )
	MenuFrame:ShowCloseButton( true )
	MenuFrame:SetDeleteOnClose( false )
	MenuFrame:SetVisible( false )
	MenuFrame:MakePopup()

	-- Create the property sheet
	local PropSheet = vgui.Create( "DPropertySheet", MenuFrame )
	PropSheet:SetPos( 6, 30 )
	PropSheet:SetSize( 256, 512 )

	-- Create the panels
	local SetupPanel = FlexPoser.Menu.CreateSetupPanel()
	local PreferencesPanel = FlexPoser.Menu.CreatePreferencesPanel()
	local QuestionnairePanel = FlexPoser.Menu.CreateQuestionnairePanel()
	local AboutPanel = FlexPoser.Menu.CreateAboutPanel()

	-- Add the panels to the property sheet
	PropSheet:AddSheet( "Setup", SetupPanel, nil, false, false, "Setup FlexPoser" )
	PropSheet:AddSheet( "Preferences", PreferencesPanel, nil, false, false, "User preferences" )
	PropSheet:AddSheet( "Questionnaire", QuestionnairePanel, nil, false, false, "Help my research" )
	PropSheet:AddSheet( "About", AboutPanel, nil, false, false, "About FlexPoser" )
	PropSheet:SetShowIcons( false )
	
	-- BOTTOM SECTION (4)
	local BottomLabel = vgui.Create( "DLabel", PropSheet )
	BottomLabel:SetTextColor( Color(255, 255, 255, 255) )
	BottomLabel:SetSize( 234, 40 )
	BottomLabel:SetPos( 11, 470 )
	BottomLabel:SetWrap( true )
	BottomLabel:SetText( "Type !flexposer or !fp in chat to show this menu at any time." )
	
	PropSheet:SizeToContents()
	MenuFrame:SizeToContents()
	
	-- Store in global table
	FlexPoser.Menu.Frame = MenuFrame
	FlexPoser.Menu.SetupPanel = SetupPanel
end