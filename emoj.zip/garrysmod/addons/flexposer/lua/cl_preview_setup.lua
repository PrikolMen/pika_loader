FlexPoser.Preview = {}

-- Initial eye target
FlexPoser.Preview.EyeTarget = Vector(100, 20, 0)

FlexPoser.Preview.Create = function()
	local ViewSize = 128
	local ContainerSize = ViewSize + 12
	
	local ViewContainer = vgui.Create( "DPanel" )
	ViewContainer:SetPos( 100, 100 )
	ViewContainer:SetSize( ContainerSize, ContainerSize + 16 )
	ViewContainer:SetVisible( false )
	
	local ModelPanel = vgui.Create( "DModelPanel", ViewContainer )	
	ModelPanel:SetPos( 6, 6 )
	ModelPanel:SetSize( ViewSize, ViewSize )
	ModelPanel:SetCamPos( Vector( 18, 0, 65.5 ) )
	ModelPanel:SetLookAt( Vector( 0, 0, 64.5 ) )
	ModelPanel:SetFOV( 40 )
	
	-- Status label for showing whether a face is detected
	surface.CreateFont( "FC_StatusFont", {
		font = "HUDNumber",
		size = 22,
		weight = 700,
		blursize = 0,
		scanlines = 0,
		antialias = false,
		underline = false,
		italic = false,
		strikeout = false,
		symbol = false,
		rotary = false,
		shadow = false,
		additive = false,
		outline = true,
	} )
	
	local StatusMessage = vgui.Create( "DLabel", ViewContainer )
	StatusMessage:SetColor( Color(50, 150, 50, 255) )
	StatusMessage:SetFont( "FC_StatusFont" )
	StatusMessage:SetText( "Status" )
	
	-- Remove the default rotating entity behavior
	function ModelPanel:LayoutEntity( Entity )
		Entity:SetAngles( Angle( 0, 0,  0) )
	end
	
	-- Store objects for later reference when changing preferences
	FlexPoser.Preview.Container = ViewContainer
	FlexPoser.Preview.Label = StatusMessage
	FlexPoser.Preview.ModelPanel = ModelPanel
end
