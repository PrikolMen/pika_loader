if SERVER then
	FlexPoser.InitNetServer = function()
		-- Network strings represent network message types
		-- Either client->server or server->client
		util.AddNetworkString( "flexposer_status" )
		util.AddNetworkString( "send_flex" )
		util.AddNetworkString( "broadcast_flex" )
		util.AddNetworkString( "flexposer_questionnaire" )
		
		-- Set handler for client message containing status change
		net.Receive( "flexposer_status", 
			function( length, ply )
				local enabled = tobool( net.ReadBit() )
				if enabled then
					PrintMessage( HUD_PRINTTALK, ply:Name() .. " is streaming his facial expression" )
				else
					PrintMessage( HUD_PRINTTALK, ply:Name() .. " stopped streaming his facial expression" )
				end
				
				FlexPoser.Tracking.OnPlayerStatus( ply, enabled )
			end
		)
		
		-- Set handler for client message containing one frame of tracking data
		net.Receive( "send_flex", 
			function( length, ply )
				net.Start( "broadcast_flex" )
				net.WriteString( ply:UniqueID() )
			
				-- Get the flex weights
				local flexWeights = {}
				for i=1,FlexPoser.Constants.NumAUs do
					flexWeights[i] = net.ReadFloat()
					net.WriteFloat( flexWeights[i] )
				end
				
				-- Get the face globals
				local globalWeights = {}
				for i=1,6 do
					globalWeights[i] = net.ReadFloat()
					net.WriteFloat( globalWeights[i] )
				end
				
				net.SendOmit( ply )
				
				-- Perform tracking
				FlexPoser.Tracking.OnPlayerData( ply, flexWeights, globalWeights )
			end 
		)
		
		net.Receive( "flexposer_questionnaire",
			function( length, ply )
				local answers = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
				for i=1,14 do
					answers[i] = net.ReadInt( 16 )
				end
				for i=15,18 do
					-- Read string, but remove punctuation to prevent SQL insertion
					answers[i] = net.ReadString():gsub( '%p', '' )
				end
				FlexPoser.Tracking.OnQSubmission( ply, answers )
			end
		)
	end
else
	-- Register message handler
	FlexPoser.InitNetClient = function()
		net.Receive( "broadcast_flex",
			function( length )
				-- Read contents
				local uniqueID = net.ReadString()
				local flexWeights = {}
				for i=1,FlexPoser.Constants.NumAUs do
					flexWeights[i] = net.ReadFloat()
				end
				local globalWeights = {}
				for i=1,6 do
					globalWeights[i] = net.ReadFloat()
				end
				
				-- Retrieve player, is false if not found
				local target = player.GetByUniqueID( uniqueID )
				
				-- Apply weights to player, if it is found
				if target then
					FlexPoser.ApplyWeights( target, flexWeights, true )
					FlexPoser.ApplyGlobals( target, globalWeights, true )
				end
			end
		)
	end
	
	-- Define function for sending tracking status
	FlexPoser.SendStatus = function( enabled )
		net.Start( "flexposer_status" )
		net.WriteBit( enabled )
		net.SendToServer()
	end
	
	-- Define function for sending one frame of tracking data
	FlexPoser.SendFlexData = function( flexWeights, globalWeights )
		net.Start( "send_flex" )
		for i=1,FlexPoser.Constants.NumAUs do
			net.WriteFloat( flexWeights[i] )
		end
		for i=1,6 do
			net.WriteFloat( globalWeights[i] )
		end
		net.SendToServer()
	end
end
