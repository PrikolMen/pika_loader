FlexPoser.Status = {}

-- Initialize status values
FlexPoser.Status.Enabled = false
FlexPoser.Status.Module = false
FlexPoser.Status.Webcam = false
FlexPoser.Status.Profile = false
FlexPoser.Status.Overall = false

-- Module sub status, each cannot become false after having been true
FlexPoser.Status.ModuleLoaded = false
FlexPoser.Status.ModuleVersion = false
FlexPoser.Status.ModuleInitialized = false

-- Updates the status icons and shows currently relevant panel
FlexPoser.UpdateStatus = function()
	-- Update status icons on GUI setup sheet
	local StatusNames = { "Enabled", "Module", "Webcam", "Profile" }
	for i=1,4 do
		local enabled = FlexPoser.Status[ StatusNames[i] ]
		local icon = FlexPoser.Menu.StatusIcons[ StatusNames[i] ]
		if enabled then
			icon:SetImage( "materials/status_success.png" )
		else
			icon:SetImage( "materials/status_failure.png" )
		end
	end
	
	-- Updates overall status value
	local PreStatus = FlexPoser.Status.Overall
	FlexPoser.Status.Overall = FlexPoser.Status.Enabled && FlexPoser.Status.Module && FlexPoser.Status.Webcam && FlexPoser.Status.Profile
	
	-- If overall status changed, notify server
	if FlexPoser.Status.Overall != PreStatus then
		FlexPoser.SendStatus( FlexPoser.Status.Overall )
	end
	
	-- If a profile is loaded, store it as auto-load
	if FlexPoser.Status.Overall then
		FlexPoser.Preferences.LastProfile = FlexPoser.Status.ProfileName
		FlexPoser.WritePreferences()
	end
	
	-- Update running panel label
	FlexPoser.Menu.RunningLabel:SetText( "Current profile: " .. FlexPoser.Status.ProfileName )
	
	-- Based on current problem (or none), show the correct panel
	if !FlexPoser.Status.Enabled then
		FlexPoser.Menu.SetStatusPanel( "Enabled" )
		FlexPoser.Preview.SetStatusMessage( "Disabled", "red" )
	elseif !FlexPoser.Status.Module then
		-- Cause is already shown by TryModule()
	elseif !FlexPoser.Status.Webcam then
		-- Refresh devices list
		FlexPoser.Menu.SetStatusPanel( "Webcam" )
		FlexPoser.Preview.SetStatusMessage( "No cam", "red" )
	elseif !FlexPoser.Status.Profile then
		-- Refresh profile list
		FlexPoser.Menu.RefreshProfilesHandler()
		FlexPoser.Menu.SetStatusPanel( "Profile" )
		FlexPoser.Preview.SetStatusMessage( "No profile", "red" )
	else
		FlexPoser.Menu.SetStatusPanel( "Running" )
		FlexPoser.Preview.SetStatusMessage( "OK", "green" )
	end
end

FlexPoser.TryModule = function()
	local errorMsg = "OK!"
	if !FlexPoser.Status.Module then
		-- Try to load module
		if !FlexPoser.Status.ModuleLoaded then
			local result, errorMsg = pcall( function() require( "flexposer" ) end )
			if result then 
				FlexPoser.Status.ModuleLoaded = true
			else
				FlexPoser.Menu.SetStatusPanel( "ModuleNotFound" )
				FlexPoser.Preview.SetStatusMessage( "DLL required", "red" )
				return false, "Module loading failed: gmcl_flexposer_win32.dll not found"
			end
		end
		
		-- Check module version
		local moduleVer = __GetFlexPoserVersion()
		local requiredVer = 4
		if moduleVer == requiredVer then
			FlexPoser.Status.ModuleVersion = true
		elseif moduleVer < requiredVer then
			FlexPoser.Menu.SetStatusPanel( "ModuleTooOld" )
			FlexPoser.Preview.SetStatusMessage( "DLL incompatible", "red" )
			return false, "Module version incorrect, exit game and download new module version from flexposer.com"
		else
			FlexPoser.Menu.SetStatusPanel( "ModuleTooNew" )
			FlexPoser.Preview.SetStatusMessage( "DLL incompatible", "red" )
			return false, "Server addon outdated"
		end
		
		-- Try to initialize module
		local initResult = __Initialize()
		if initResult == 0 then
			FlexPoser.Status.ModuleInitialized = true
		elseif initResult == 1 then
			FlexPoser.Menu.SetStatusPanel( "ModuleFace2" )
			FlexPoser.Preview.SetStatusMessage( "Files missing", "red" )
			return false, "Module initialization failed, fp_face2.tracker missing"
		elseif initResult == 2 then
			FlexPoser.Menu.SetStatusPanel( "ModuleHaar" )
			FlexPoser.Preview.SetStatusMessage( "Files missing", "red" )
			return false, "Module initialization failed, fp_haar.xml missing"
		elseif initResult == 3 then
			FlexPoser.Menu.SetStatusPanel( "ModuleFace2Haar" )
			FlexPoser.Preview.SetStatusMessage( "Files missing", "red" )
			return false, "Module initialization failed, fp_face2.tracker and fp_haar.xml both missing"
		end
		
		FlexPoser.Status.Module = true
		FlexPoser.ApplyPreferences()
		FlexPoser.Menu.RefreshDevicesHandler()
		return true, "OK!"
	end
	
	-- Update overall module status and return it
	return true, "already loaded!"
end

-- Tries to load binary module if not already loaded and
-- tries to connect to webcam if not already connected
FlexPoser.TryConnect = function( deviceIndex )
	FlexPoser.Preferences.LastCamera = deviceIndex

	-- If module was not loaded yet, try to load module
	if !FlexPoser.Status.Module then
		return
	end
	
	local result = __StartTracking( deviceIndex )
	if result == 0 then
		FlexPoser.Status.Webcam = true
		return true, "OK!"
	else
		FlexPoser.Status.Webcam = false
		FlexPoser.Menu.SetStatusPanel( "Webcam" )
		FlexPoser.Preview.SetStatusMessage( "Webcam required", "red" )
		return false, "Cannot access camera"
	end
end

FlexPoser.TryEnable = function()
	-- Attempt to load module
	local status1, error1 = FlexPoser.TryModule()
	if !status1 then
		--print( error1 )
		return
	end
	--print( "Module success!" )	
	
	-- Attempt auto-connect if enabled
	if FlexPoser.Preferences.AutoConnect then
		-- Try to connect webcam
		local status2, error2 = FlexPoser.TryConnect( FlexPoser.Preferences.AutoConnectIndex )
		if !status2 then
			--print( error2 )
			return
		end
		
		FlexPoser.Status.Webcam = true
		--print( "Connection success!" )
	end
end