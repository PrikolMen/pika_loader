FlexPoser.LastOverall = false
FlexPoser.LastModel = nil
FlexPoser.LastSentFrameID = -1
FlexPoser.ErrorCodes = { "Unknown", "WebcamSetup", "WebcamRead", "TrackingSetup", "TrackingExec", "VerificationSetup", "VerificationExec", "ClientCallback" }

FlexPoser.UpdateFace = function()
	-- Keep preview panel models in sync with player model
	if LocalPlayer():GetModel() != FlexPoser.LastModel then
		FlexPoser.LastModel = LocalPlayer():GetModel()
		
		-- Update preview panel models
		FlexPoser.Preview.ModelPanel:SetModel( LocalPlayer():GetModel() )
		FlexPoser.Wizard.ModelPanel:SetModel( LocalPlayer():GetModel() )
		
		-- Set eye targets
		FlexPoser.Preview.ModelPanel:GetEntity():SetEyeTarget(FlexPoser.Preview.EyeTarget)
		FlexPoser.Wizard.ModelPanel:GetEntity():SetEyeTarget(FlexPoser.Preview.EyeTarget)
	end
	
	-- Check whether status is OK
	if FlexPoser.Status.Webcam then
		local moduleStatus = __GetStatus()
		if moduleStatus != 0 then
			-- Webcam status changed
			FlexPoser.Status.Webcam = false
			FlexPoser.UpdateStatus()
			
			-- Hide wizard
			FlexPoser.Wizard.Close()
		
			-- Show error
			local errorMsg = FlexPoser.ErrorCodes[ status ]
			FlexPoser.Menu.ShowError( "An error occured while attempting to read from your webcam. Press Retry to resume tracking.", "Error" )
			return
		end
	end
	
	-- Check if all setup conditions are satisfied
	if !FlexPoser.Status.Overall then
		-- Not all conditions are met (enabled/module/webcam/profile)
		return
	elseif !__IsFaceDetected() then
		-- No face detected in current webcam image
		FlexPoser.Preview.SetStatusMessage( "No face", "red" )
		return
	else
		-- All is well
		FlexPoser.Preview.SetStatusMessage( "Live!", "green" )
	end
	
	-- Retrieve most recent tracking data from image processing library
	local distances =  { __GetDistances() }		-- Raw vertex distances (15 distances between pairs of vertices)
	local globals = { __GetGlobals() }			-- Raw global params (scale, pitch, yaw, roll, tx, ty)
	
	-- Compute flex weights with respect to profile data, by linear interpolation
	local profileData = FlexPoser.Profiles[ FlexPoser.Status.ProfileName ]
	local flexWeights = { }
	for i=1,FlexPoser.Constants.NumAUs do
		local dist = distances[i]
		local neutral = profileData.Neutral[i]
		local max = profileData.Maxima[i]
		local pending = ( dist - neutral ) / ( max - neutral )
		flexWeights[i] = math.Clamp( pending, 0, 1 )
	end
	
	-- Compute global weights with respect to profile data
	local globalWeights = { 0, 0, 0, 0, 0, 0 }
	if FlexPoser.Preferences.TrackRotation then
		local globalScales = { 1, -60, 60, 60, 1, 1 }
		
		if !FlexPoser.Preferences.TrackPitch then globalScales[2] = 0 end
		if !FlexPoser.Preferences.TrackYaw then globalScales[3] = 0 end
		if !FlexPoser.Preferences.TrackRoll then globalScales[4] = 0 end
		
		for i=1,6 do
			local offset = globals[i] - profileData.Global[i]
			globalWeights[i] = globalScales[i] * offset
		end
	end
	
	-- Apply flex weights to player model and preview entities 
	-- Functions defined in shared_apply_weights.lua
	local entities = { LocalPlayer(), FlexPoser.Preview.ModelPanel:GetEntity(), FlexPoser.Wizard.ModelPanel:GetEntity() }
	for i=1, table.getn(entities) do
		-- Player models behave differently from character models, pass this as a parameter to the apply functions
		local isPlayer = 1 == 1
		FlexPoser.ApplyWeights( entities[i], flexWeights, isPlayer )
		FlexPoser.ApplyGlobals( entities[i], globalWeights, isPlayer )
	end
	
	-- If a new webcam frame has been processed since last message, send the tracking data to the game server
	local FrameID = __GetFrameID()
	if (FrameID != FlexPoser.LastSentFrameID) then
		FlexPoser.SendFlexData( flexWeights, globalWeights )
		FlexPoser.LastSentFrameID = FrameID
	end
end