FlexPoser.Wizard = {}

FlexPoser.Wizard.CreateNameEntry = function()
	FlexPoser.Wizard.NameEntry = {}
	FlexPoser.Wizard.NameEntry.MaxChars = 20
	
	local NameEntryFrame = vgui.Create( "DFrame" )
	NameEntryFrame:SetSize( 212, 76 )
	NameEntryFrame:SetTitle( "Enter name for new profile" )
	NameEntryFrame:SetDraggable( true )
	NameEntryFrame:ShowCloseButton( false )
	NameEntryFrame:SetDeleteOnClose( false )
	NameEntryFrame:Center()
	NameEntryFrame:SetVisible( false )
	
	local LimitText = function( NameEntryField )
		local txt = NameEntryField:GetValue()
		local amt = string.len(txt)
		if amt > FlexPoser.Wizard.NameEntry.MaxChars then
			NameEntryField:SetText(NameEntryField.OldText)
			NameEntryField:SetValue(NameEntryField.OldText)
			NameEntryField:SetCaretPos(FlexPoser.Wizard.NameEntry.MaxChars)
		else
			NameEntryField.OldText = txt
		end
	end
	
	local NameEntryField = vgui.Create( "DTextEntry", NameEntryFrame )
	NameEntryField:SetPos( 6, 25 )
	NameEntryField:SetSize( 200, 20 )
	NameEntryField:SetEnterAllowed( true )
	NameEntryField.OnEnter = FlexPoser.Wizard.NameEnteredHandler
	NameEntryField.OnTextChanged = LimitText
	NameEntryField:SetText( "" )
	
	
	local CancelButton = vgui.Create( "DButton", NameEntryFrame )
	CancelButton:SetPos( 106 - 97 - 3, 50 )
	CancelButton:SetSize( 97, 20 )
	CancelButton:SetText( "Cancel" )
	CancelButton.DoClick = FlexPoser.Wizard.NameCancelHandler
	
	local NextButton = vgui.Create( "DButton", NameEntryFrame )
	NextButton:SetPos( 106 + 3, 50 )
	NextButton:SetSize( 97, 20 )
	NextButton:SetText( "Next" )
	NextButton.DoClick = FlexPoser.Wizard.NameEnteredHandler
	
	FlexPoser.Wizard.NameEntry.Frame = NameEntryFrame
	FlexPoser.Wizard.NameEntry.Field = NameEntryField
end

FlexPoser.Wizard.CreateTipsFrame = function()
	-- Create the calibration GUI
	local TipsFrame = vgui.Create( "DFrame" )
	TipsFrame:SetSize( 400, 150 )
	TipsFrame:SetTitle( "FlexPoser tips" )
	TipsFrame:SetDraggable( true )
	TipsFrame:ShowCloseButton( true )
	TipsFrame:SetDeleteOnClose( false )
	TipsFrame:SetPos( ScrW() / 2 + 200, ScrH() / 2 - 75 )
	TipsFrame:SetVisible( false )
	FlexPoser.Wizard.TipsFrame = TipsFrame
	
	local StatusLabel1 = vgui.Create( "DLabel", TipsFrame )
	StatusLabel1:SetPos( 10, 20 )
	StatusLabel1:SetSize( 380, 130 )
	StatusLabel1:SetWrap( true )
	StatusLabel1:SetTextColor( Color( 200, 200, 200, 255 ) )
	
	local txt = "Tips to improve face tracking quality: \n" ..
	"- Make sure your face is completely visible in the webcam image \n" ..
	"- Make sure your face is uniformly lit (no dark shadows) \n" ..
	"- Make sure mouth and eyebrows are clearly visible \n" ..
	"- Avoid bright light such as sunlight from the back or side \n" ..
	"- Glasses and facial hair may affect tracking quality, but are generally fine \n"
	
	StatusLabel1:SetText( txt )
	
end

FlexPoser.Wizard.Create = function()
	FlexPoser.Wizard.CreateTipsFrame()

	-- Create the calibration GUI
	local WizardFrame = vgui.Create( "DFrame" )
	WizardFrame:SetSize( 312, 312 )
	WizardFrame:SetTitle( "FlexPoser profile setup" )
	WizardFrame:SetDraggable( true )
	WizardFrame:ShowCloseButton( true )
	WizardFrame:SetDeleteOnClose( false )
	WizardFrame:Center()
	WizardFrame:SetVisible( false )
	
	-- Create all the pages
	FlexPoser.Wizard.Pages = {}
	FlexPoser.Wizard.Pages[1]  = FlexPoser.Wizard.CreatePage( false, false, "materials/wait.png", "The white rectangle represents your face. Position \nyour camera and your seat so that the white rectangle \nis inside the yellow box." )
	
	local PositionPanel = vgui.Create( "DPanel", FlexPoser.Wizard.Pages[1] )
	PositionPanel:SetPos( 150 - 90, 20 )
	PositionPanel:SetSize( 180, 135 )
	PositionPanel.Paint = function()
		local W = PositionPanel:GetWide()
		local H = PositionPanel:GetTall()
			
		-- Draw black background
		surface.SetDrawColor( 50, 50, 50, 255 ) 
		surface.DrawRect( 0, 0, W, H )
		
		-- Draw target rectangle
		surface.SetDrawColor( 255, 255, 0, 255 )
		surface.DrawOutlinedRect( 0.2 * W, 0.2 * H, 0.6 * W, 0.6 * H )
		
		-- Draw face estimation
		if __IsFaceDetected() then
			local bounds = { __GetFTRect() }
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawRect( bounds[1] * W, bounds[2] * H, bounds[3] * W, bounds[4] * H )
			
			--print( tostring(bounds[1]) .. ", " .. tostring(bounds[2]) .. ", " .. tostring(bounds[3]) .. ", " .. tostring(bounds[4]) )
		end
	end
	
	FlexPoser.Wizard.Pages[2]  = FlexPoser.Wizard.CreatePage( false, false, "materials/ex1.png", "Make a neutral expression and press Next" )
	
	-- Instructions pages
	FlexPoser.Wizard.Pages[3]  = FlexPoser.Wizard.CreatePage( false, false, nil, "You will now have to mimic 6 poses. \nHold each pose until you hear a beep." )
	FlexPoser.Wizard.Pages[4]  = FlexPoser.Wizard.CreatePage( true, false, "materials/ex2.png", "Open your eyes widely"  )
	FlexPoser.Wizard.Pages[5]  = FlexPoser.Wizard.CreatePage( true, false, "materials/ex3.png", "Look mad"  )
	FlexPoser.Wizard.Pages[6]  = FlexPoser.Wizard.CreatePage( true, false, "materials/ex4.png", "Raise your eyebrows" )
	FlexPoser.Wizard.Pages[7]  = FlexPoser.Wizard.CreatePage( true, false, "materials/ex5.png", "Smile with mouth closed" )
	FlexPoser.Wizard.Pages[8] = FlexPoser.Wizard.CreatePage( true, false, "materials/ex6.png", "Make a small o with your mouth"  )
	FlexPoser.Wizard.Pages[9] = FlexPoser.Wizard.CreatePage( true, false, "materials/ex7.png", "Make a large O with your mouth"  )
	
	-- Finished pages
	FlexPoser.Wizard.Pages[10] = FlexPoser.Wizard.CreatePage( false, true, nil, "Try making facial expressions. Press \nFinish if the result is satisfactory." )
	FlexPoser.Wizard.Pages[11] = FlexPoser.Wizard.CreatePage( false, false, nil, "Tips" )
	
	-- Hide back button on certain screens
	FlexPoser.Wizard.Pages[1].BackButton:SetVisible( false )
	FlexPoser.Wizard.Pages[11].NextButton:SetVisible( false )
	
	-- If auto calibrating, hide next buttons on all gesture pages
	if FlexPoser.Preferences.AutoCalibrate then
		for i=4,9 do
			FlexPoser.Wizard.Pages[i].NextButton:SetVisible( false )
		end
	end
	
	-- Change button text on some screens
	FlexPoser.Wizard.Pages[1].BackButton:SetText( "Help" )
	FlexPoser.Wizard.Pages[10].BackButton:SetText( "Restart" )
	FlexPoser.Wizard.Pages[10].NextButton:SetText( "Finish" )
		
	-- Keep references to dynamic elements
	--FlexPoser.Wizard.SnapImageA = FlexPoser.Wizard.Pages[1].Image
	FlexPoser.Wizard.ModelPanel = FlexPoser.Wizard.Pages[10].ModelPanel
	
	-- Set parent for all and make pages invisible
	local NumPages = table.getn(FlexPoser.Wizard.Pages)
	for i=1, NumPages do
		FlexPoser.Wizard.Pages[i]:SetVisible( false )
		FlexPoser.Wizard.Pages[i]:SetParent( WizardFrame )
	end
	
	-- Initialize settings
	FlexPoser.Wizard.Frame = WizardFrame
	FlexPoser.Wizard.PageID = 1
	FlexPoser.Wizard.Page = FlexPoser.Wizard.Pages[1]
	FlexPoser.Wizard.Page:SetVisible( true )
	FlexPoser.Wizard.Process = {}

	FlexPoser.Wizard.CreateNameEntry()
end

-- Creates a simple 
FlexPoser.Wizard.CreatePage = function( bStatusIcon, bModelPanel, imgPath, caption )
	local SimplePage = vgui.Create( "DPanel" )
	SimplePage:SetPos( 6, 26 )
	SimplePage:SetSize( 300, 280 )

	if imgPath != nil then
		local CheckImage = vgui.Create( "DImage", SimplePage )
		CheckImage:SetImage( imgPath )
		CheckImage:SetPos( 150 - 64, 20 )
		CheckImage:SizeToContents()
		
		SimplePage.Image = CheckImage
	end
	
	if bStatusIcon then
		local StatusIcon = vgui.Create( "DImage", SimplePage )
		StatusIcon:SetImage( "materials/status_failure.png" )
		StatusIcon:SetPos( 150 + 64 + 5, 20 + 128 - 36 )
		StatusIcon:SizeToContents()
		
		local StatusLabel1 = vgui.Create( "DLabel", SimplePage )
		StatusLabel1:SetText( "Face" )
		StatusLabel1:SetTextColor( Color(0, 0, 0, 255) )
		StatusLabel1:SizeToContents()
		StatusLabel1:SetPos( 150 + 64 + 25, 20 + 128 - 36 )
		
		local StatusIcon2 = vgui.Create( "DImage", SimplePage )
		StatusIcon2:SetImage( "materials/status_failure.png" )
		StatusIcon2:SetPos( 150 + 64 + 5, 20 + 128 - 16 )
		StatusIcon2:SizeToContents()
		
		local StatusLabel2 = vgui.Create( "DLabel", SimplePage )
		StatusLabel2:SetText( "Pose" )
		StatusLabel2:SetTextColor( Color(0, 0, 0, 255) )
		StatusLabel2:SizeToContents()
		StatusLabel2:SetPos( 150 + 64 + 25, 20 + 128 - 16 )
		
		SimplePage.StatusIcon = StatusIcon
		SimplePage.StatusIcon2 = StatusIcon2
	end
	
	if bModelPanel then
		-- Preview panel
		local viewSize = 120
		local ViewContainer = vgui.Create( "DPanel", SimplePage )
		ViewContainer:SetPos( 150 - viewSize / 2, 20 )
		ViewContainer:SetSize( viewSize, viewSize )
		ViewContainer.Paint = function() 
			surface.SetDrawColor( 0, 0, 0, 255 ) 
			surface.DrawRect( 0, 0, ViewContainer:GetWide(), ViewContainer:GetTall() )
		end
		
		local ModelPanel = vgui.Create( "DModelPanel", ViewContainer )
		ModelPanel:SetSize( viewSize, viewSize )
		ModelPanel:SetCamPos( Vector( 16, 0, 64 ) )
		ModelPanel:SetLookAt( Vector( 0, 0, 64 ) )
		ModelPanel:SetFOV( 40 )
	
		function ModelPanel:LayoutEntity( Entity )
			Entity:SetAngles( Angle( 0, 0,  0) )
		end
		SimplePage.ModelPanel = ModelPanel
	end
	
	-- Label
	local InfoLabel = vgui.Create( "DLabel", SimplePage )
	InfoLabel:SetText( caption )
	InfoLabel:SetContentAlignment( 5 )
	InfoLabel:SetTextColor( Color(0, 0, 0, 255) )
	if imgPath != nil || bModelPanel then
		InfoLabel:SetPos( 150, 160 )
	else
		InfoLabel:SetPos( 150, 100 )
	end
	InfoLabel:SetSize( 300, 50 )
	InfoLabel:CenterHorizontal()
	
	-- Previous button
	local BackButton = vgui.Create( "DButton", SimplePage )
	BackButton:SetSize( 100, 40 )
	BackButton:SetPos( 150 - 100 - 20, 210 )
	BackButton:SetText( "Back" )
	BackButton.DoClick = FlexPoser.Wizard.BackHandler

	-- Next button
	local NextButton = vgui.Create( "DButton", SimplePage )
	NextButton:SetSize( 100, 40 )
	NextButton:SetPos( 150 + 20, 210 )
	NextButton:SetText( "Next" )
	NextButton.DoClick = FlexPoser.Wizard.NextHandler
	
	SimplePage.InfoLabel = InfoLabel
	SimplePage.BackButton = BackButton
	SimplePage.NextButton = NextButton
	
	return SimplePage
end