FlexPoser.Menu.ButtonHeight = 20
FlexPoser.Menu.ButtonSpacing = 23

FlexPoser.Menu.CreateSetupPanel = function()
	local sepY1 = 130
	local sepY2 = 250
	local spacing = 5
	local margin = 10
	
	local SetupSheet = vgui.Create( "DPanel" )
	SetupSheet:SetPaintBackground( false )
	
	-- INFO SECTION (1)
	local InfoSection = vgui.Create( "DPanel" )
	InfoSection:SetParent( SetupSheet )
	InfoSection:SetPos( 0, 0 )
	InfoSection:SetSize( 256, sepY1 )

	local InfoLabel = vgui.Create( "DLabel", InfoSection )
	InfoLabel:SetTextColor( Color(0, 0, 0, 255) )
	InfoLabel:SetWrap( true )
	InfoLabel:SetSize( 234 - 2 * margin, 80 )
	InfoLabel:SetPos( margin, 0 )
	InfoLabel:SetText( "FlexPoser allows you to control your character's facial expression with your webcam and show it to other players.\n\nTrack my facial expression:" )
	
	local EnableButton = vgui.Create( "DButton", InfoSection )
	EnableButton:SetSize( 200, 40 )
	EnableButton:SetPos( 234 / 2 - 100, 80 )
	EnableButton:SetText( "Enable" )
	EnableButton.DoClick = FlexPoser.Menu.EnableButtonHandler
	
	-- Store button in global table, so that it can be edited when clicked
	FlexPoser.Menu.EnableButton = EnableButton
	
	-- STATUS SECTION (2)
	local StatusSection = vgui.Create( "DPanel" )
	StatusSection:SetParent( SetupSheet )
	StatusSection:SetPos( 0, sepY1 + spacing )
	StatusSection:SetSize( 256, sepY2 - sepY1 )

	local StatusLabel = vgui.Create( "DLabel", StatusSection )
	StatusLabel:SetTextColor( Color(0, 0, 0, 255) )
	StatusLabel:SetWrap( true )
	StatusLabel:SetSize( 234, 40 )
	StatusLabel:SetPos( 50, 0 )
	StatusLabel:SetText( "Status" )
	
	local StatusPanel = vgui.Create( "DPanel", StatusSection )
	StatusPanel:SetPos( 45, 30 )
	StatusPanel:SetSize( 144, 70 )
	StatusPanel.Paint = function () 
		surface.SetDrawColor( 180, 180, 180, 255 )
		surface.DrawRect( 0, 0, 144, 70 )
	end
	
	-- Check list
	local CheckListTexts = { "FlexPoser enabled", "Binary module loaded", "Webcam selected", "Profile loaded" }
	local IconNames = { "Enabled", "Module", "Webcam", "Profile" }
	FlexPoser.Menu.StatusIcons = {}
	for i=1,4 do
		local CheckLabel = vgui.Create( "DLabel", StatusPanel )
		CheckLabel:SetTextColor( Color(0, 0, 0, 255) )
		CheckLabel:SetSize( 234, 40 )
		CheckLabel:SetPos( 5, -8 + (i - 1) * 15 )
		CheckLabel:SetText( CheckListTexts[i] )
		
		local CheckImage = vgui.Create( "DImage", StatusPanel )
		CheckImage:SetImage( "materials/status_unknown.png" )
		CheckImage:SetPos( 125, 6 + (i - 1) * 15 )
		CheckImage:SizeToContents()
		
		-- Store image object globally for updating icons
		FlexPoser.Menu.StatusIcons[IconNames[i]] = CheckImage
	end
	
	-- HINT SECTION - DYNAMIC (3)
	local EnablePanel = FlexPoser.Menu.CreateSimplePanel( "Click Enable to start using FlexPoser.\n\n", false, nil )
	local ProfilePanel = FlexPoser.Menu.CreateProfilePanel()
	local RunningPanel = FlexPoser.Menu.CreateRunningPanel()
	
	-- Error panels
	local ModuleNotFoundPanel = FlexPoser.Menu.CreateSimplePanel( "FlexPoser requires a DLL that must be manually downloaded. Please follow the instructions on www.flexposer.com/download.php \n\nYou can stay on the server, just press Retry when the DLL is downloaded.", true, "Retry" )
	local ModuleTooNewPanel = FlexPoser.Menu.CreateSimplePanel( "The server addon is outdated. The newest version is available in the workshop. Please contact the admin.", false, nil )
	local ModuleTooOldPanel = FlexPoser.Menu.CreateSimplePanel( "Your binary module is outdated and cannot be used on this server. Please exit the game and download the latest from www.flexposer.com.", false, nil )
	local ModuleFace2Panel = FlexPoser.Menu.CreateSimplePanel( "The binary module is loaded, but is missing the file fp_face2.tracker. Redownload it from www.flexposer.com and press Retry.", true, "Retry" )
	local ModuleHaarPanel = FlexPoser.Menu.CreateSimplePanel( "The binary module is loaded, but is missing the file fp_haar.xml. Redownload it from www.flexposer.com and press Retry.", true, "Retry" )
	local ModuleFace2HaarPanel = FlexPoser.Menu.CreateSimplePanel( "The binary module is loaded, but is missing the files fp_face2.tracker and fp_haar.xml. Redownload the files from www.flexposer.com and press Retry.", true, "Retry" )
	local WebcamPanel = FlexPoser.Menu.CreateWebcamPanel()
	local ErrorPanel = FlexPoser.Menu.CreateSimplePanel( "Wildcard panel.", true, "Retry" )
	
	-- Initialize and store the swappable panels
	local PanelList = { EnablePanel, ProfilePanel, RunningPanel, ModuleNotFoundPanel, ModuleTooNewPanel, ModuleTooOldPanel, ModuleFace2Panel, ModuleHaarPanel, ModuleFace2HaarPanel, WebcamPanel, ErrorPanel }
	local PanelNames = { "Enabled", "Profile", "Running", "ModuleNotFound", "ModuleTooNew", "ModuleTooOld", "ModuleFace2", "ModuleHaar", "ModuleFace2Haar", "Webcam", "Error" }
	FlexPoser.Menu.Panels = {}
	for i=1,table.getn( PanelList ) do
		PanelList[i]:SetParent( SetupSheet )
		PanelList[i]:SetVisible( false )
		FlexPoser.Menu.Panels[PanelNames[i]] = PanelList[i]
	end
	
	-- Set current panel manually
	FlexPoser.Menu.Panel = EnablePanel
	FlexPoser.Menu.Panel:SetVisible( true )
	
	return SetupSheet
end

FlexPoser.Menu.CreateSimplePanel = function( infoText, showButton, buttonText )
	local sepY1 = 130
	local sepY2 = 250
	local spacing = 5
	
	-- Section
	local SimplePanel = vgui.Create( "DPanel" )
	SimplePanel:SetPos( 0, sepY2 + 2 * spacing )
	SimplePanel:SetSize( 256, 180 )
	
	-- Label
	local InfoLabel = vgui.Create( "DLabel", SimplePanel )
	InfoLabel:SetTextColor( Color(0, 0, 0, 255) )
	InfoLabel:SetAutoStretchVertical( true )
	InfoLabel:SetWrap( true )
	InfoLabel:SetSize( 234, 50 )
	InfoLabel:SetPos( 5, 8 )
	InfoLabel:SetText( infoText )
	SimplePanel.InfoLabel = InfoLabel
	
	-- Button
	if showButton then
		local LoadButton = vgui.Create( "DButton", SimplePanel )
		LoadButton:SetSize( 200, 40 )
		LoadButton:SetPos( 234 / 2 - 100, 120 )
		LoadButton:SetText( buttonText )
		LoadButton.DoClick = FlexPoser.Menu.RetryHandler
		SimplePanel.LoadButton = LoadButton
	end
	
	return SimplePanel
end

FlexPoser.Menu.CreateWebcamPanel = function()
	local sepY1 = 130
	local sepY2 = 250
	local spacing = 5
	
	-- Section
	local WebcamPanel = vgui.Create( "DPanel" )
	WebcamPanel:SetPos( 0, sepY2 + 2 * spacing )
	WebcamPanel:SetSize( 256, 180 )
	
	-- Label
	local InfoLabel = vgui.Create( "DLabel", WebcamPanel )
	InfoLabel:SetTextColor( Color(0, 0, 0, 255) )
	InfoLabel:SetAutoStretchVertical( true )
	InfoLabel:SetWrap( true )
	InfoLabel:SetPos( 5, 8 )
	InfoLabel:SetSize( 234, 30 )
	InfoLabel:SetText( "Please select a webcam." )
	WebcamPanel.FoundLabel = InfoLabel
	
	-- Label2
	local SelectLabel = vgui.Create( "DLabel", WebcamPanel )
	SelectLabel:SetTextColor( Color(0, 0, 0, 255) )
	SelectLabel:SetAutoStretchVertical( true )
	SelectLabel:SetWrap( true )
	SelectLabel:SetPos( 24, 150 - 4 * FlexPoser.Menu.ButtonSpacing + 3 )
	SelectLabel:SetSize( 100, 30 )
	SelectLabel:SetText( "Devices:" )
	
	-- Combo Box
	local TestingComboBox = vgui.Create( "DComboBox", WebcamPanel )
	TestingComboBox:SetSize( 150, FlexPoser.Menu.ButtonHeight )
	TestingComboBox:SetPos( 234 - 150 - 17, 150 - 4 * FlexPoser.Menu.ButtonSpacing )
	TestingComboBox:SetValue( "---" )
	FlexPoser.Menu.WebcamComboIndex = 0
	FlexPoser.Menu.WebcamComboBox = TestingComboBox
	TestingComboBox.OnSelect = function( panel, index, value, data) 
		FlexPoser.Menu.WebcamComboIndex = index - 1
	end
	
	local AutoConnectBox = vgui.Create( "DCheckBoxLabel", WebcamPanel )
	AutoConnectBox:SetPos( 25, 150 - 3 * FlexPoser.Menu.ButtonSpacing + 3 )
	AutoConnectBox:SetChecked( FlexPoser.Preferences.AutoConnect )
	AutoConnectBox:SetText( "Auto-connect on Enable" )
	AutoConnectBox:SetTextColor( Color(0, 0, 0, 255) )
	AutoConnectBox:SizeToContents()
	AutoConnectBox.OnChange = function()
		FlexPoser.Preferences.AutoConnect = AutoConnectBox:GetChecked()
		FlexPoser.WritePreferences()
	end
	WebcamPanel.AutoConnectBox = AutoConnectBox
	
	-- Connect/Refresh
	local UseButton = vgui.Create( "DButton", WebcamPanel )
	UseButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	UseButton:SetPos( 234 / 2 - 100, 150 - 2 * FlexPoser.Menu.ButtonSpacing )
	UseButton:SetText( "Use this device" )
	UseButton.DoClick = FlexPoser.Menu.UseWebcamHandler
	
	local RefreshButton = vgui.Create( "DButton", WebcamPanel )
	RefreshButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	RefreshButton:SetPos( 234 / 2 - 100, 150 - FlexPoser.Menu.ButtonSpacing )
	RefreshButton:SetText( "Refresh list" )
	RefreshButton.DoClick = FlexPoser.Menu.RefreshDevicesHandler
	
	-- Label
	local ErrorLabel = vgui.Create( "DLabel", WebcamPanel )
	ErrorLabel:SetTextColor( Color(255, 0, 0, 255) )
	ErrorLabel:SetSize( 234, 30 )
	ErrorLabel:SetPos( 45, 150 )
	ErrorLabel:SetText( "Could not access this device." )
	ErrorLabel:SetVisible( false )
	WebcamPanel.ErrorLabel = ErrorLabel
	
	return WebcamPanel
end

FlexPoser.Menu.CreateProfilePanel = function()
	local sepY1 = 130
	local sepY2 = 250
	local spacing = 5
	
	-- Section
	local SimplePanel = vgui.Create( "DPanel" )
	SimplePanel:SetPos( 0, sepY2 + 2 * spacing )
	SimplePanel:SetSize( 256, 180 )
	
	-- Label
	local InfoLabel = vgui.Create( "DLabel", SimplePanel )
	InfoLabel:SetTextColor( Color(0, 0, 0, 255) )
	InfoLabel:SetAutoStretchVertical( true )
	InfoLabel:SetWrap( true )
	InfoLabel:SetPos( 5, 8 )
	InfoLabel:SetSize( 234, 30 )
	InfoLabel:SetText( "Almost there! We need some information about your face. Please create or load a profile:" )
	
	local CameraButton = vgui.Create( "DButton", SimplePanel )
	CameraButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	CameraButton:SetPos( 234 / 2 - 100, 150 - 4 * FlexPoser.Menu.ButtonSpacing - 10 )
	CameraButton:SetText( "Change device" )
	CameraButton.DoClick = FlexPoser.Menu.SwitchWebcamHandler
	
	-- Label2
	local SelectLabel = vgui.Create( "DLabel", SimplePanel )
	SelectLabel:SetTextColor( Color(0, 0, 0, 255) )
	SelectLabel:SetAutoStretchVertical( true )
	SelectLabel:SetWrap( true )
	SelectLabel:SetPos( 24, 150 - 3 * FlexPoser.Menu.ButtonSpacing + 3 )
	SelectLabel:SetSize( 100, 30 )
	SelectLabel:SetText( "Profiles:" )
	
	-- Combo Box
	local TestingComboBox = vgui.Create( "DComboBox", SimplePanel )
	TestingComboBox:SetPos( 234 - 150 - 17, 150 - 3 * FlexPoser.Menu.ButtonSpacing )
	TestingComboBox:SetSize( 150, FlexPoser.Menu.ButtonHeight )
	TestingComboBox:SetValue( "---" )
	FlexPoser.Menu.ProfileComboSelection = "---"
	FlexPoser.Menu.ProfileComboBox = TestingComboBox
	TestingComboBox.OnSelect = function( panel, index, value, data) 
		FlexPoser.Menu.ProfileComboSelection = value 
	end
	
	-- Create/Load/Delete buttons	
	local CreateButton = vgui.Create( "DButton", SimplePanel )
	CreateButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	CreateButton:SetPos( 234 / 2 - 100, 150 - 2 * FlexPoser.Menu.ButtonSpacing )
	CreateButton:SetText( "Create profile" )
	CreateButton.DoClick = FlexPoser.Menu.CreateProfileHandler
	
	local LoadButton = vgui.Create( "DButton", SimplePanel )
	LoadButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	LoadButton:SetPos( 234 / 2 - 100, 150 - FlexPoser.Menu.ButtonSpacing )
	LoadButton:SetText( "Load profile" )
	LoadButton.DoClick = FlexPoser.Menu.LoadProfileHandler
	
	local DeleteButton = vgui.Create( "DButton", SimplePanel )
	DeleteButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	DeleteButton:SetPos( 234 / 2 - 100, 150 )
	DeleteButton:SetText( "Delete profile" )
	DeleteButton.DoClick = FlexPoser.Menu.DeleteProfileHandler
	
	return SimplePanel
end

FlexPoser.Menu.CreateRunningPanel = function()
	local sepY1 = 130
	local sepY2 = 250
	local spacing = 5
	
	-- Section
	local SimplePanel = vgui.Create( "DPanel" )
	SimplePanel:SetPos( 0, sepY2 + 2 * spacing )
	SimplePanel:SetSize( 256, 180 )
	
	local RunningLabel = vgui.Create( "DLabel", SimplePanel )
	RunningLabel:SetTextColor( Color(50, 150, 50, 255) )
	RunningLabel:SetSize( 234 - 40, 14 )
	RunningLabel:SetPos( 234 / 2 - 80, 24 )
	RunningLabel:SetText( "Running!" )
	
	-- Label
	FlexPoser.Status.ProfileName = "???"
	local InfoLabel = vgui.Create( "DLabel", SimplePanel )
	InfoLabel:SetTextColor( Color(0, 0, 0, 255) )
	InfoLabel:SetSize( 234 - 40, 14 )
	InfoLabel:SetPos( 234 / 2 - 80, 40 )
	FlexPoser.Menu.RunningLabel = InfoLabel
	
	-- Buttons
	local camButton = vgui.Create( "DButton", SimplePanel )
	camButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	camButton:SetPos( 234 / 2 - 100, 150 - 3 * FlexPoser.Menu.ButtonSpacing )
	camButton:SetText( "Change webcam" )
	camButton.DoClick = FlexPoser.Menu.SwitchWebcamHandler
	
	local switchButton = vgui.Create( "DButton", SimplePanel )
	switchButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	switchButton:SetPos( 234 / 2 - 100, 150 - 2 * FlexPoser.Menu.ButtonSpacing )
	switchButton:SetText( "Change profile" )
	switchButton.DoClick = FlexPoser.Menu.SwitchProfileHandler
	
	local recalibButton = vgui.Create( "DButton", SimplePanel )
	recalibButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	recalibButton:SetPos( 234 / 2 - 100, 150 - FlexPoser.Menu.ButtonSpacing )
	recalibButton:SetText( "Redo profile setup" )
	recalibButton.DoClick = FlexPoser.Menu.RecalibrateHandler
	
	local centerHeadButton = vgui.Create( "DButton", SimplePanel )
	centerHeadButton:SetSize( 200, FlexPoser.Menu.ButtonHeight )
	centerHeadButton:SetPos( 234 / 2 - 100, 150 )
	centerHeadButton:SetText( "Recenter head rotation" )
	centerHeadButton.DoClick = FlexPoser.Menu.CenterHeadHandler
	
	return SimplePanel
end