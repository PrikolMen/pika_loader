FlexPoser.Tracking = {}
FlexPoser.Tracking.FailedAttempts = 0
FlexPoser.Tracking.Failed = false
FlexPoser.Tracking.Ended = true

-- Load or create the convar fp_trackingenabled
local contents = file.Read( "flexposer_cfg.txt" )
if !contents then
	FlexPoser.Tracking.EnabledCV = CreateConVar( "fp_trackingenabled", 1, FCVAR_NOTIFY )
else
	local val = 0
	local enabled = tobool( contents )
	if enabled then val = 1 end
	FlexPoser.Tracking.EnabledCV = CreateConVar( "fp_trackingenabled", val, FCVAR_NOTIFY )
end

-- Message types
FlexPoser.Tracking.TYPE_SESSION_START = 0				-- Submits new session with mode name, map name. Requests session ID.
FlexPoser.Tracking.TYPE_SESSION_END = 1					-- Submits session summary.
FlexPoser.Tracking.TYPE_PLAYER_EVENT = 2				-- Submits a player event during the session, see PEVENT_.
FlexPoser.Tracking.TYPE_PARTICIPATION_SUMMARY = 3		-- Submits an anonymous summary of player's face tracked data over the entire session.
FlexPoser.Tracking.TYPE_PERIODIC_SUMMARY = 4			-- Submits an anonymous summary of player's face tracked data periodically every ~3 minutes.
FlexPoser.Tracking.TYPE_QSUBMISSION = 5					-- Submits a questionnaire answer. All questionnaire data passes through server so that tracking server address is not in client-side LUA.
FlexPoser.Tracking.TypeNames = { "session_start", "session_end", "player_event", "participation_summary", "periodic_summary", "questionnaire" }

-- Player event types, to be sent with TYPE_PLAYER_EVENT messages
FlexPoser.Tracking.PEVENT_JOIN = 0			-- Player joins game
FlexPoser.Tracking.PEVENT_LEAVE = 1			-- Player leaves game
FlexPoser.Tracking.PEVENT_ENABLE = 2		-- Player enables FlexPoser
FlexPoser.Tracking.PEVENT_DISABLE = 3		-- Player disables FlexPoser

-- Message queue while waiting for HTTP response including session ID
FlexPoser.Tracking.QueuedMessages = {}

-- Tracked lists
FlexPoser.Tracking.AllPlayerList = {}			-- All players ever during session
FlexPoser.Tracking.ConnectedPlayerList = {}		-- All connected players
FlexPoser.Tracking.TrackedPlayerList = {}		-- All tracked players

-- Player data for everyone who has been tracked during the session
FlexPoser.Tracking.PlayerData = {}

-- Tracked server stats
FlexPoser.Tracking.NumTracked = 0
FlexPoser.Tracking.NumUsers = 0
FlexPoser.Tracking.PeakTracked = 0
FlexPoser.Tracking.PeakUsers = 0
FlexPoser.Tracking.PeakRatio = 0

-- Helper function for sending a message to tracking server
FlexPoser.SendTrackingData = function( msgtype, data, succ, fail )
	-- Tracking period ended on August 14th, 2014
	if FlexPoser.Tracking.Ended then
		return
	end
	
	-- If session ID request failed or tracking disabled by admin, do nothing
	if FlexPoser.Tracking.Failed or !FlexPoser.Tracking.EnabledCV:GetBool() then
		return
	end

	-- If no session ID assigned yet and msgtype is not session_start,
	-- queue message until session ID is received
	if !FlexPoser.Tracking.SessionID and msgtype != FlexPoser.Tracking.TYPE_SESSION_START then
		----print( "FlexPoser: Queueing message of type: " .. FlexPoser.Tracking.TypeNames[ msgtype + 1 ] )
		
		-- Prepare message container
		local msg = { }
		msg['type'] = msgtype
		msg['data'] = data
		msg['succ'] = succ
		msg['fail'] = fail
		
		-- Add to queue
		local queuedCount = table.getn( FlexPoser.Tracking.QueuedMessages )
		FlexPoser.Tracking.QueuedMessages[ queuedCount + 1 ] = msg
		return
	else 
		----print( "FlexPoser: Sending message of type: " .. FlexPoser.Tracking.TypeNames[ msgtype + 1 ] )
	end

	-- Default values of arguments
	if !data then data = {} end
	if !succ then succ = function( body, len, headers, code ) end end
	if !fail then fail = function( err ) end end
	
	-- Append message header
	data["type"] = tostring( msgtype )
	if msgtype != FlexPoser.Tracking.TYPE_SESSION_START then
		data["sessionid"] = FlexPoser.Tracking.SessionID
	end
	
	-- Convert all message data to string
	for k,v in pairs( data ) do
		data[k] = tostring( v )
		----print( k .. " | " .. v )
	end
	
	-- Send post request
	local url = "http://zkshao.com/scripts/exp3_submit.php"
	http.Post( url, data, succ, fail )
end

FlexPoser.Tracking.OnPlayerStatus = function( ply, enabled )
	-- Tracking period ended on August 14th, 2014
	if FlexPoser.Tracking.Ended then
		return
	end
	
	-- If session ID request failed or tracking disabled by admin, do nothing
	if FlexPoser.Tracking.Failed or !FlexPoser.Tracking.EnabledCV:GetBool() then
		return
	end
	
	-- Compute hashed player id
	local uid = ply:UniqueID()

	if enabled then
		-- Update active list, send SessionEvent
		FlexPoser.Tracking.TrackedPlayerList[uid] = true
		FlexPoser.SendTrackingData( FlexPoser.Tracking.TYPE_PLAYER_EVENT, { player = sha1(uid), pevent = FlexPoser.Tracking.PEVENT_ENABLE } )
		
		-- Make sure player data container exists
		if !FlexPoser.Tracking.PlayerData[uid] then
			----print( "FlexPoser: Creating player data entry for player " .. uid )
			
			FlexPoser.Tracking.PlayerData[uid] = {}
			FlexPoser.Tracking.PlayerData[uid].N = 0
			FlexPoser.Tracking.PlayerData[uid].FlexMeans = {}
			FlexPoser.Tracking.PlayerData[uid].FlexM2s = {}
			FlexPoser.Tracking.PlayerData[uid].GlobMeans = {}
			FlexPoser.Tracking.PlayerData[uid].GlobM2s = {}
			FlexPoser.Tracking.PlayerData[uid].ExpressiveCount = 0
			FlexPoser.Tracking.PlayerData[uid].TotalTime = 0
			
			FlexPoser.Tracking.PlayerData[uid].PeriodicN = 0
			FlexPoser.Tracking.PlayerData[uid].PeriodicFlexMeans = {}
			FlexPoser.Tracking.PlayerData[uid].PeriodicFlexM2s = {}
			FlexPoser.Tracking.PlayerData[uid].PeriodicGlobMeans = {}
			FlexPoser.Tracking.PlayerData[uid].PeriodicGlobM2s = {}
			FlexPoser.Tracking.PlayerData[uid].PeriodicExpressiveCount = 0
			
			for i=1,15 do
				FlexPoser.Tracking.PlayerData[uid].FlexMeans[i] = 0
				FlexPoser.Tracking.PlayerData[uid].FlexM2s[i] = 0
				FlexPoser.Tracking.PlayerData[uid].PeriodicFlexMeans[i] = 0
				FlexPoser.Tracking.PlayerData[uid].PeriodicFlexM2s[i] = 0
			end
			for i=1,6 do
				FlexPoser.Tracking.PlayerData[uid].GlobMeans[i] = 0
				FlexPoser.Tracking.PlayerData[uid].GlobM2s[i] = 0
				FlexPoser.Tracking.PlayerData[uid].PeriodicGlobMeans[i] = 0
				FlexPoser.Tracking.PlayerData[uid].PeriodicGlobM2s[i] = 0
			end
			
			FlexPoser.Tracking.PlayerData[uid].LastPeriodicSendTime = RealTime()
			FlexPoser.Tracking.PlayerData[uid].TotalTime = 0
		end
		
		-- Log moment of enabling
		FlexPoser.Tracking.PlayerData[uid].StartTime = RealTime()
		
		-- Update num tracked, peak tracked and peak ratio
		FlexPoser.Tracking.NumTracked = FlexPoser.Tracking.NumTracked + 1
		FlexPoser.Tracking.PeakTracked = math.max( FlexPoser.Tracking.PeakTracked, FlexPoser.Tracking.NumTracked )
		
		if FlexPoser.Tracking.NumUsers >= 4 then
			FlexPoser.Tracking.PeakRatio = math.max( FlexPoser.Tracking.PeakRatio, FlexPoser.Tracking.NumTracked / FlexPoser.Tracking.NumUsers )
		end
	else
		-- Update active list, send SessionEvent
		FlexPoser.Tracking.TrackedPlayerList[uid] = nil
		FlexPoser.SendTrackingData( FlexPoser.Tracking.TYPE_PLAYER_EVENT, { player = sha1(uid), pevent = FlexPoser.Tracking.PEVENT_DISABLE } )
		
		-- Compute and count duration towards total time
		local duration = RealTime() - FlexPoser.Tracking.PlayerData[uid].StartTime
		FlexPoser.Tracking.PlayerData[uid].TotalTime = FlexPoser.Tracking.PlayerData[uid].TotalTime + duration
		
		-- Update num tracked
		FlexPoser.Tracking.NumTracked = FlexPoser.Tracking.NumTracked - 1
	end
end

FlexPoser.Tracking.CountFailedRequest = function( reason )
	-- Tracking period ended on August 14th, 2014
	if FlexPoser.Tracking.Ended then
		return
	end
	
	FlexPoser.Tracking.FailedAttempts = FlexPoser.Tracking.FailedAttempts + 1
	if FlexPoser.Tracking.FailedAttempts > 5 then
		print( reason .. ", failure limit reached, not tracking this session" )
		FlexPoser.Tracking.Failed = true
	else
		print( reason .. ", retrying in 3 seconds" )
		timer.Create( "RequestSessionID", 3.0, 1, FlexPoser.Tracking.RequestSessionID )
	end
end

FlexPoser.Tracking.RequestSessionID = function()
	-- Tracking period ended on August 14th, 2014
	if FlexPoser.Tracking.Ended then
		return
	end
	
	-- If tracking disabled by admin, do nothing
	if !FlexPoser.Tracking.EnabledCV:GetBool() then
		print( "FlexPoser: fp_trackingenabled == 0, not tracking this session" )
		return
	end
	
	--print( "FlexPoser: Requesting session ID" )

	-- Prepare response handler for session ID request
	local succ = function( body, len, headers, code )	
			-- Check whether HTTP response received
			if len == 0 then
				FlexPoser.Tracking.CountFailedRequest( "FlexPoser: HTTP response empty" )
				return
			end
			
			-- Check line existence
			local split_into_lines = function(str)
				local t = {}
				local function helper(line) table.insert(t, line) return "" end
				helper((str:gsub("(.-)\r?\n", helper)))
				return t
			end
			
			local pieces = split_into_lines( body )
			if table.getn( pieces ) < 8 then
				FlexPoser.Tracking.CountFailedRequest( "FlexPoser: HTTP response too short" )
				return
			end
			
			-- Check line is number
			local sessionID = tonumber( pieces[8] )
			if !sessionID then
				FlexPoser.Tracking.CountFailedRequest( "FlexPoser: HTTP response not correctly formatted" )
				return
			end
			
			-- Session ID received
			FlexPoser.Tracking.SessionID = sessionID
			--print( "FlexPoser: Session ID is now: " .. FlexPoser.Tracking.SessionID )
			
			-- Send queued messages
			local queuedCount = table.getn( FlexPoser.Tracking.QueuedMessages )
			----print( "FlexPoser: Sending " .. queuedCount .. " queued messages")
			for i=1, queuedCount do
				local msg = FlexPoser.Tracking.QueuedMessages[ i ]
				FlexPoser.SendTrackingData( msg['type'], msg['data'], msg['succ'], msg['fail'] )
			end
		end
	
	local fail = function( err ) FlexPoser.Tracking.CountFailedRequest( "FlexPoser: " .. err ) end
	
	-- Send session info
	FlexPoser.SendTrackingData( FlexPoser.Tracking.TYPE_SESSION_START, { map = game.GetMap(), mode = GAMEMODE_NAME }, succ, fail )
end

FlexPoser.Tracking.OnSessionStart = function()
	-- Tracking period ended on August 14th, 2014
	if FlexPoser.Tracking.Ended then
		return
	end
	
	-- Don't track single player games
	if game.SinglePlayer() then
		print( "FlexPoser: Single player, not tracking session" )
		FlexPoser.Tracking.Failed = true
		return
	end
	
	-- If tracking disabled by admin, do nothing
	if !FlexPoser.Tracking.EnabledCV:GetBool() then
		print( "FlexPoser: fp_trackingenabled == 0, not tracking this session" )
		return
	end

	-- Log session start time
	FlexPoser.Tracking.StartTime = RealTime()
	
	-- Request session ID with delay, because ISteamHTTP service needs time to start
	timer.Create( "RequestSessionID", 3.0, 1, FlexPoser.Tracking.RequestSessionID )
end

FlexPoser.Tracking.OnSessionEnd = function()
	-- Tracking period ended on August 14th, 2014
	if FlexPoser.Tracking.Ended then
		return
	end
	
	local contents = tostring( FlexPoser.Tracking.EnabledCV:GetBool() )
	file.Write( "flexposer_cfg.txt", contents )

	-- If session ID request failed or tracking disabled by admin, do nothing
	if FlexPoser.Tracking.Failed or !FlexPoser.Tracking.EnabledCV:GetBool() then
		return
	end

	-- Send session summary
	local matchDuration = math.floor( RealTime() - FlexPoser.Tracking.StartTime + 0.5 )
	FlexPoser.SendTrackingData( FlexPoser.Tracking.TYPE_SESSION_END, { 
		duration = matchDuration,
		peak_users = FlexPoser.Tracking.PeakUsers,
		peak_tracked = FlexPoser.Tracking.PeakTracked,
		peak_ratio = FlexPoser.Tracking.PeakRatio,
	} )
	
	-- Finalize players currently being tracked
	for uid, unused in pairs( FlexPoser.Tracking.ConnectedPlayerList ) do
		----print( "FlexPoser: Manually dropping player with UID " .. uid )
		FlexPoser.Tracking.OnPlayerLeft( player.GetByUniqueID( uid ) )
	end
	
	-- Send player summaries
	for uid, unused in pairs( FlexPoser.Tracking.AllPlayerList ) do
		local msgdata = {}
		msgdata[ "player" ] = sha1(uid)
		msgdata[ "used_addon" ] = 0
		
		-- If this player used the addon, send summary as well
		if FlexPoser.Tracking.PlayerData[uid] then
			local pdata = FlexPoser.Tracking.PlayerData[uid]
			msgdata[ "used_addon" ] = 1
			msgdata[ "duration" ] = pdata.TotalTime
			
			for i=1,15 do
				local avg = pdata.FlexMeans[i]
				local var = pdata.FlexM2s[i] / ( pdata.N - 1 )
				msgdata[ "au" .. tostring(i) .. "_avg" ] = avg
				msgdata[ "au" .. tostring(i) .. "_var" ] = var
			end
			
			for i=1,6 do
				local avg = pdata.GlobMeans[i]
				local var = pdata.GlobM2s[i] / ( pdata.N - 1 )
				msgdata[ "glob" .. tostring(i) .. "_avg" ] = avg
				msgdata[ "glob" .. tostring(i) .. "_var" ] = var
			end
			
			msgdata[ "expressive_metric_1" ] = pdata.ExpressiveCount / pdata.N
		end
		
		FlexPoser.SendTrackingData( FlexPoser.Tracking.TYPE_PARTICIPATION_SUMMARY, msgdata )
	end
end

FlexPoser.Tracking.OnPlayerJoined = function( ply )
	-- Tracking period ended on August 14th, 2014
	if FlexPoser.Tracking.Ended then
		return
	end
	
	-- If session ID request failed or tracking disabled by admin, do nothing
	if FlexPoser.Tracking.Failed or !FlexPoser.Tracking.EnabledCV:GetBool() then
		return
	end
	
	-- Update player lists and send event
	local uid = ply:UniqueID()
	FlexPoser.Tracking.AllPlayerList[uid] = true
	FlexPoser.Tracking.ConnectedPlayerList[uid] = true
	FlexPoser.SendTrackingData( FlexPoser.Tracking.TYPE_PLAYER_EVENT, { player = sha1(uid), pevent = FlexPoser.Tracking.PEVENT_JOIN } )
	
	-- Update num users and peak users
	FlexPoser.Tracking.NumUsers = FlexPoser.Tracking.NumUsers + 1
	FlexPoser.Tracking.PeakUsers = math.max( FlexPoser.Tracking.PeakUsers, FlexPoser.Tracking.NumUsers )
	
	if FlexPoser.Tracking.NumUsers >= 8 then
		FlexPoser.Tracking.PeakRatio = math.max( FlexPoser.Tracking.PeakRatio, FlexPoser.Tracking.NumTracked / FlexPoser.Tracking.NumUsers )
	end
end

FlexPoser.Tracking.OnPlayerLeft = function( ply )
	-- Tracking period ended on August 14th, 2014
	if FlexPoser.Tracking.Ended then
		return
	end
	
	-- If session ID request failed or tracking disabled by admin, do nothing
	if FlexPoser.Tracking.Failed or !FlexPoser.Tracking.EnabledCV:GetBool() then
		return
	end
	
	-- Update player lists
	local uid = ply:UniqueID()
	FlexPoser.Tracking.ConnectedPlayerList[uid] = nil
	
	-- If player was being tracked, generate player status change
	if FlexPoser.Tracking.TrackedPlayerList[ ply:UniqueID() ] then
		FlexPoser.Tracking.OnPlayerStatus( ply, false )
	end
	
	-- Send leave event
	FlexPoser.SendTrackingData( FlexPoser.Tracking.TYPE_PLAYER_EVENT, { player = sha1(uid), pevent = FlexPoser.Tracking.PEVENT_LEAVE } )
	
	-- Update num users and peak ratio
	FlexPoser.Tracking.NumUsers = FlexPoser.Tracking.NumUsers - 1
	
	if FlexPoser.Tracking.NumUsers >= 8 then
		FlexPoser.Tracking.PeakRatio = math.max( FlexPoser.Tracking.PeakRatio, FlexPoser.Tracking.NumTracked / FlexPoser.Tracking.NumUsers )
	end
end

FlexPoser.Tracking.OnPlayerData = function( ply, flexWeights, globalWeights )
	-- Tracking period ended on August 14th, 2014
	if FlexPoser.Tracking.Ended then
		return
	end

	-- If session ID request failed or tracking disabled by admin, do nothing
	if FlexPoser.Tracking.Failed or !FlexPoser.Tracking.EnabledCV:GetBool() then
		return
	end
	
	local uid = ply:UniqueID()
	
	-- Check whether we were aware that this player was tracking
	if !FlexPoser.Tracking.TrackedPlayerList[uid] then
		FlexPoser.Tracking.OnPlayerStatus( ply, true )
	end
	
	-- Add the sample
	FlexPoser.Tracking.PlayerData[uid].N = FlexPoser.Tracking.PlayerData[uid].N + 1
	FlexPoser.Tracking.PlayerData[uid].PeriodicN = FlexPoser.Tracking.PlayerData[uid].PeriodicN + 1
	for i=1,15 do
		local delta = flexWeights[i] - FlexPoser.Tracking.PlayerData[uid].FlexMeans[i];
		FlexPoser.Tracking.PlayerData[uid].FlexMeans[i] = FlexPoser.Tracking.PlayerData[uid].FlexMeans[i] + delta / FlexPoser.Tracking.PlayerData[uid].N
		FlexPoser.Tracking.PlayerData[uid].FlexM2s[i] = FlexPoser.Tracking.PlayerData[uid].FlexM2s[i] + delta * (flexWeights[i] - FlexPoser.Tracking.PlayerData[uid].FlexMeans[i])
		
		local delta2 = flexWeights[i] - FlexPoser.Tracking.PlayerData[uid].PeriodicFlexMeans[i];
		FlexPoser.Tracking.PlayerData[uid].PeriodicFlexMeans[i] = FlexPoser.Tracking.PlayerData[uid].PeriodicFlexMeans[i] + delta2 / FlexPoser.Tracking.PlayerData[uid].PeriodicN
		FlexPoser.Tracking.PlayerData[uid].PeriodicFlexM2s[i] = FlexPoser.Tracking.PlayerData[uid].PeriodicFlexM2s[i] + delta2 * (flexWeights[i] - FlexPoser.Tracking.PlayerData[uid].PeriodicFlexMeans[i])
	end
	for i=1,6 do
		local delta = globalWeights[i] - FlexPoser.Tracking.PlayerData[uid].GlobMeans[i];
		FlexPoser.Tracking.PlayerData[uid].GlobMeans[i] = FlexPoser.Tracking.PlayerData[uid].GlobMeans[i] + delta / FlexPoser.Tracking.PlayerData[uid].N
		FlexPoser.Tracking.PlayerData[uid].GlobM2s[i] = FlexPoser.Tracking.PlayerData[uid].GlobM2s[i] + delta * (globalWeights[i] - FlexPoser.Tracking.PlayerData[uid].GlobMeans[i])
		
		local delta2 = globalWeights[i] - FlexPoser.Tracking.PlayerData[uid].PeriodicGlobMeans[i];
		FlexPoser.Tracking.PlayerData[uid].PeriodicGlobMeans[i] = FlexPoser.Tracking.PlayerData[uid].PeriodicGlobMeans[i] + delta2 / FlexPoser.Tracking.PlayerData[uid].PeriodicN
		FlexPoser.Tracking.PlayerData[uid].PeriodicGlobM2s[i] = FlexPoser.Tracking.PlayerData[uid].PeriodicGlobM2s[i] + delta2 * (globalWeights[i] - FlexPoser.Tracking.PlayerData[uid].PeriodicGlobMeans[i])
	end
	
	-- Metric 1: Count a frame as expressive if any AU is above 0.75
	for i=3,14 do
		if flexWeights[i] > 0.75 then
			FlexPoser.Tracking.PlayerData[uid].ExpressiveCount = FlexPoser.Tracking.PlayerData[uid].ExpressiveCount + 1
			FlexPoser.Tracking.PlayerData[uid].PeriodicExpressiveCount = FlexPoser.Tracking.PlayerData[uid].PeriodicExpressiveCount + 1
			break
		end
	end
	
	-- Send periodic player summary
	if FlexPoser.Tracking.PlayerData[uid].PeriodicN > 600 then
		local timespan = RealTime() - FlexPoser.Tracking.PlayerData[uid].LastPeriodicSendTime
		if timespan > 180 then
			-- Append player id
			local msgdata = {}
			msgdata[ "player" ] = sha1(uid)
			
			-- Append periodic summary
			local pdata = FlexPoser.Tracking.PlayerData[uid]
			for i=1,15 do
				local avg = pdata.PeriodicFlexMeans[i]
				local var = pdata.PeriodicFlexM2s[i] / ( pdata.PeriodicN - 1 )
				msgdata[ "au" .. tostring(i) .. "_avg" ] = avg
				msgdata[ "au" .. tostring(i) .. "_var" ] = var
			end
			for i=1,6 do
				local avg = pdata.PeriodicGlobMeans[i]
				local var = pdata.PeriodicGlobM2s[i] / ( pdata.PeriodicN - 1 )
				msgdata[ "glob" .. tostring(i) .. "_avg" ] = avg
				msgdata[ "glob" .. tostring(i) .. "_var" ] = var
			end
			msgdata[ "expressive_metric_1" ] = pdata.PeriodicExpressiveCount / pdata.PeriodicN
			
			-- Send the data
			FlexPoser.SendTrackingData( FlexPoser.Tracking.TYPE_PERIODIC_SUMMARY, msgdata )
			
			-- Reset periodic data
			FlexPoser.Tracking.PlayerData[uid].PeriodicN = 0
			FlexPoser.Tracking.PlayerData[uid].PeriodicExpressiveCount = 0
			for i=1,15 do
				FlexPoser.Tracking.PlayerData[uid].PeriodicFlexMeans[i] = 0
				FlexPoser.Tracking.PlayerData[uid].PeriodicFlexM2s[i] = 0
			end
			for i=1,6 do
				FlexPoser.Tracking.PlayerData[uid].PeriodicGlobMeans[i] = 0
				FlexPoser.Tracking.PlayerData[uid].PeriodicGlobM2s[i] = 0
			end
			FlexPoser.Tracking.PlayerData[uid].LastPeriodicSendTime = RealTime()
			
			----print( "FlexPoser: Sent periodic summary for: " .. ply:Name() )
		end
	end
end

FlexPoser.Tracking.OnQSubmission = function( ply, answers )
	local fieldNames = {
		"field1",
		"field2",
		"field3",
		"field4",
		"field5",
		"field6",
		"field7",
		"field8",
		"field9",
		"field10",
		"field11",
		"field12",
		"field13",
		"field14",
		"field15",
		"field16",
		"field17",
		"field18",
	}
	
	for i=2,3 do
		if answers[i] < 0 or answers[i] > 1000 then
			answers[i] = -1
		end
	end
	
	local data = {}
	data["player"] = sha1( ply:UniqueID() )
	
	for i=1,18 do
		data[ fieldNames[i] ] = tostring( answers[i] )
		----print( fieldNames[i] .. " = " .. tostring( answers[i] ) )
	end
	
	FlexPoser.SendTrackingData( FlexPoser.Tracking.TYPE_QSUBMISSION, data )
end