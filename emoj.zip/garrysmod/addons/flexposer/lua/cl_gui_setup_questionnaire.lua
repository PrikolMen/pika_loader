FlexPoser.Questionnaire = {}
FlexPoser.Questionnaire.LastSend = 0

FlexPoser.Questionnaire.SendAnswers = function( answers )
	if RealTime() - FlexPoser.Questionnaire.LastSend < 1 then
		-- Prevent submit spam
		return
	else
		FlexPoser.Questionnaire.LastSend = RealTime()
	end

	local serializedAns = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
	
	-- Process answers 1-14 to ints
	if answers[1] == "Male" then
		serializedAns[1] = 1
	else
		serializedAns[1] = 2
	end
	
	serializedAns[2] = tonumber( answers[2] )
	serializedAns[3] = tonumber( answers[3] )
	
	if answers[4] == "Yes" then
		serializedAns[4] = 1
	else
		serializedAns[4] = 2
	end
	
	for i=5,9 do
		if answers[i] then serializedAns[i] = 1 else serializedAns[i] = 0 end
	end
	
	for i=10,11 do
		if answers[i] == "1 - Never" then
			serializedAns[i] = 1
		elseif answers[i] == "5 - All the time" then
			serializedAns[i] = 5
		else
			local pending = tonumber( answers[i] )
			if pending then 
				serializedAns[i] = pending
			else
				serializedAns[i] = -1
			end
		end
	end
	
	for i=12,14 do
		if answers[i] then serializedAns[i] = 1 else serializedAns[i] = 0 end
	end
	
	-- Keep answers 15-18 as strings
	for i=15,18 do
		serializedAns[i] = answers[i]
	end
	
	-- Send all
	net.Start( "flexposer_questionnaire" )
	for i=1,14 do
		net.WriteInt( serializedAns[i], 16 )
	end
	for i=15,18 do
		net.WriteString( serializedAns[i] )
	end
	net.SendToServer()
end

FlexPoser.Questionnaire.CreateFrame = function()
	-- Create the frame
	local width = 400
	local height = 680
	local margin = 6
	local w2 = width - 2 * margin
	local sy = 41
	local sx0 = 10
	local sx = 20

	-- Create the main GUI
	local QFrame = vgui.Create( "DFrame" )
	QFrame:SetSize( width + 2 * margin, height + 22 + 2 * margin )
	QFrame:Center()
	QFrame:SetTitle( "Questionnaire" )
	QFrame:SetDraggable( true )
	QFrame:ShowCloseButton( true )
	QFrame:SetDeleteOnClose( false )
	QFrame:SetVisible( false )
	
	local APanel = vgui.Create( "DPanel", QFrame )
	APanel:SetPos( margin, 22 + margin )
	APanel:SetSize( width, height )
	
	local createLabel = function( y, txt )
		local lbl = vgui.Create( "DLabel", APanel )
		lbl:SetText( txt )
		lbl:SetColor( Color(0, 0, 0, 255) )
		lbl:SetPos( sx0, 5 + y * sy )
		lbl:SetSize( w2, 20 )
		return lbl
	end
	
	local createDropDown = function( y, options )
		local cBox = vgui.Create( "DComboBox", APanel )
		cBox:SetPos( sx, 25 + y * sy )
		cBox:SetSize( 200, 20 )
		for k, v in ipairs( options ) do
			cBox:AddChoice( v )
		end
		cBox:SetValue( "" )
		return cBox
	end
	
	local numericOnly = function( fld )
		local txt = fld:GetValue()
		if !tonumber(txt) and string.len(txt) > 0 then
			if !fld.OldText then
				fld.OldText = ""
			end
		
			fld:SetText(fld.OldText)
			fld:SetValue(fld.OldText)
			fld:SetCaretPos(string.len(fld.OldText))
		elseif tonumber(txt) && tonumber(txt) > 168 then
			fld.OldText = "168"
			fld:SetText(fld.OldText)
			fld:SetValue(fld.OldText)
			fld:SetCaretPos(string.len(fld.OldText))
		else
			fld.OldText = txt
		end
	end
	
	local createField = function( y, onChange )
		local fld = vgui.Create( "DTextEntry", APanel )
		fld:SetPos( sx, 25 + y * sy )
		fld:SetSize( 200, 20 )
		fld:SetEnterAllowed( false )
		fld.OnTextChanged = onChange
		fld:SetText( "" )
		return fld
	end
	
	local createMultiCheck = function( y, options, fpl )
		local boxList = {}
		boxList.checkBoxes = {}
		
		for k,v in ipairs(options) do
			local chck = vgui.Create( "DCheckBoxLabel", APanel )
			local gx = (k - 1) % fpl
			local gy = ((k - 1) - gx) / fpl
			
			chck:SetPos( sx + gx * 200, 28 + y * sy + gy * 20 )
			chck:SetText( v )
			chck:SetTextColor( Color(0, 0, 0, 255) )
			chck:SizeToContents()
			chck:SetValue( false )
			boxList.checkBoxes[k] = chck
		end
		
		function boxList:SetVisible( vis )
			for k,v in ipairs( self.checkBoxes ) do
				v:SetVisible( vis )
			end
		end
		
		return boxList
	end
	
	FlexPoser.Questionnaire.Labels = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
	FlexPoser.Questionnaire.Inputs = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
	
	FlexPoser.Questionnaire.Labels[1] = createLabel( 0, "What is your gender?" )
	FlexPoser.Questionnaire.Inputs[1] = createDropDown( 0, { "Male", "Female" } )
	
	FlexPoser.Questionnaire.Labels[2] = createLabel( 1, "What is your age?" )
	FlexPoser.Questionnaire.Inputs[2] = createField( 1, numericOnly )
	
	FlexPoser.Questionnaire.Labels[3] = createLabel( 2, "How many hours per week do you spend on gaming related activities?" )
	FlexPoser.Questionnaire.Inputs[3] = createField( 2, numericOnly )
	
	FlexPoser.Questionnaire.Labels[4] = createLabel( 3, "Have you used FlexPoser to track your facial expression?" )
	FlexPoser.Questionnaire.Inputs[4] = createDropDown( 3, { "Yes", "No" } )
	FlexPoser.Questionnaire.Inputs[4].OnSelect = function( panel, index, value, data ) 
		local showCat = true
		if value == "No" then
			showCat = false
		end
		
		for i=5,10 do 
			FlexPoser.Questionnaire.Labels[i]:SetVisible( showCat )
			FlexPoser.Questionnaire.Inputs[i]:SetVisible( showCat )
		end
	end
	
	FlexPoser.Questionnaire.Labels[5] = createLabel( 4, "For what purposes have you used or will you use FlexPoser?" )
	FlexPoser.Questionnaire.Inputs[5] = createMultiCheck( 4, { "Screenshots", "Machinima", "Natural communication (non RP)", "Serious role-play", "Non-serious role-play" }, 2 )
	
	FlexPoser.Questionnaire.Labels[6] = createLabel( 6, "On a scale from 1 to 5, how often do you use text chat in multiplayer?" )
	FlexPoser.Questionnaire.Inputs[6] = createDropDown( 6, { "1 - Never", "2", "3", "4", "5 - All the time" } )

	FlexPoser.Questionnaire.Labels[7] = createLabel( 7, "On a scale from 1 to 5, how often do you use voice chat in multiplayer?" )
	FlexPoser.Questionnaire.Inputs[7] = createDropDown( 7, { "1 - Never", "2", "3", "4", "5 - All the time" } )
	
	FlexPoser.Questionnaire.Labels[8] = createLabel( 8, "With FlexPoser enabled, which of the following applies to you?" )
	FlexPoser.Questionnaire.Inputs[8] = createMultiCheck( 8, { "I make more use of text chat than usual", "I make more use of voice chat than usual", "I make more facial expressions than usual" }, 1 )
	
	FlexPoser.Questionnaire.Labels[9] = createLabel( 10, "What do you think of the tracking and animation quality of FlexPoser?" )
	FlexPoser.Questionnaire.Inputs[9] = createField( 10 )
	
	FlexPoser.Questionnaire.Labels[10] = createLabel( 11, "What do you think of the ease-of-use of FlexPoser?" )
	FlexPoser.Questionnaire.Inputs[10] = createField( 11 )
	
	FlexPoser.Questionnaire.Labels[11] = createLabel( 12, "What games/genres would you like to see a feature like FlexPoser in?" )
	FlexPoser.Questionnaire.Inputs[11] = createField( 12 )
	
	FlexPoser.Questionnaire.Labels[12] = createLabel( 13, "." )
	FlexPoser.Questionnaire.Inputs[12] = createField( 13 )
	
	local lbl1 = vgui.Create( "DLabel", APanel )
	lbl1:SetText( "" )
	lbl1:SetColor( Color(0, 0, 0, 255) )
	lbl1:SetPos( sx0, 5 + 14 * sy )
	lbl1:SetSize( w2, 40 )
	lbl1:SetWrap( true )
	FlexPoser.Questionnaire.ResultLabel = lbl1
	
	local SubmitButton = vgui.Create( "DButton", APanel )
	SubmitButton:SetSize( 200, 40 )
	SubmitButton:SetPos( width / 2 - 100, height - 60 )
	SubmitButton:SetText( "Submit" )
	SubmitButton.DoClick = function()		
		local multiCheck5 = FlexPoser.Questionnaire.Inputs[5]
		local multiCheck8 = FlexPoser.Questionnaire.Inputs[8]
		
		local fieldValues = {
			FlexPoser.Questionnaire.Inputs[1]:GetValue(),
			FlexPoser.Questionnaire.Inputs[2]:GetText(),
			FlexPoser.Questionnaire.Inputs[3]:GetText(),
			FlexPoser.Questionnaire.Inputs[4]:GetValue(),
			multiCheck5.checkBoxes[1]:GetChecked(),
			multiCheck5.checkBoxes[2]:GetChecked(),
			multiCheck5.checkBoxes[3]:GetChecked(),
			multiCheck5.checkBoxes[4]:GetChecked(),
			multiCheck5.checkBoxes[5]:GetChecked(),
			FlexPoser.Questionnaire.Inputs[6]:GetValue(),
			FlexPoser.Questionnaire.Inputs[7]:GetValue(),
			multiCheck8.checkBoxes[1]:GetChecked(),
			multiCheck8.checkBoxes[2]:GetChecked(),
			multiCheck8.checkBoxes[3]:GetChecked(),
			FlexPoser.Questionnaire.Inputs[9]:GetText(),
			FlexPoser.Questionnaire.Inputs[10]:GetText(),
			FlexPoser.Questionnaire.Inputs[11]:GetText(),
			FlexPoser.Questionnaire.Inputs[12]:GetText(),
		}
		
		-- Check values
		local okay = true
		local ansIndices = { 1, 2, 3, 4, 10, 11 }
		local questIndices = { 1, 2, 3, 4, 6, 7 }
		for i=1,6 do
			if string.len( tostring( fieldValues[ ansIndices[i] ] ) ) == 0 and (i <= 4 or fieldValues[4] != "No") then
				FlexPoser.Questionnaire.Labels[ questIndices[i] ]:SetColor( Color( 255, 0, 0, 255 ) )
				okay = false
			else
				FlexPoser.Questionnaire.Labels[ questIndices[i] ]:SetColor( Color( 0, 0, 0, 255 ) )
			end
		end
		
		-- Update GUi and send, based on check result
		if okay then
			FlexPoser.Questionnaire.SendAnswers( fieldValues )
			FlexPoser.Questionnaire.ResultLabel:SetText( "Your answers have been sent. You may submit as many times as you want. Only your last submission will be saved." )
			FlexPoser.Questionnaire.ResultLabel:SetColor( Color( 0, 120, 0, 255 ) )
		else
			FlexPoser.Questionnaire.ResultLabel:SetText( "Some required fields are not filled in. Please review the red questions." )
			FlexPoser.Questionnaire.ResultLabel:SetColor( Color( 255, 0, 0, 255 ) )
		end
	end
	
	FlexPoser.QuestionnaireFrame = QFrame
end

FlexPoser.Menu.CreateQuestionnairePanel = function()
	FlexPoser.Questionnaire.CreateFrame()

	-- Create panel
	local QPanel = vgui.Create( "DPanel" )
	QPanel:SizeToContents()
	QPanel:SetPaintBackground( false )
	
	local APanel = vgui.Create( "DPanel", QPanel )
	APanel:SetPos( 0, 0 )
	APanel:SetSize( 256, 440 )
	
	local lbl = vgui.Create( "DLabel", APanel )
	lbl:SetText( "FlexPoser is part of my graduation project. Please help me out by filling out this in-game questionnaire. It should take about 2 minutes. -NisshokuZK" )
	lbl:SetColor( Color(0, 0, 0, 255) )
	lbl:SetWrap( true )
	lbl:SetPos( 5, 5 )
	lbl:SetSize( 234, 3 * 20 )
	
	local EnableButton = vgui.Create( "DButton", APanel )
	EnableButton:SetSize( 200, 40 )
	EnableButton:SetPos( 234 / 2 - 100, 80 )
	EnableButton:SetText( "Open" )
	EnableButton.DoClick = function()
		FlexPoser.QuestionnaireFrame:SetVisible( true )
		FlexPoser.QuestionnaireFrame:MakePopup()
	end
		
	return QPanel
end