FlexPoser.Profiles = {}

FlexPoser.ReadProfiles = function()
	--print( "FlexPoser: Reading profiles" )
	
	local split_into_lines = function(str)
		local t = {}
		local function helper(line) table.insert(t, line) return "" end
		helper((str:gsub("(.-)\r?\n", helper)))
		return t
	end
	
	local contents = file.Read( "flexposer_profiles.txt" )
	if contents != nil then
		-- Split file contents into lines
		local lines = split_into_lines( contents )
		local finger = 1
		
		-- Read number of profiles
		local NumProfiles = tonumber(lines[finger])
		finger = finger + 1
		
		--print( NumProfiles .. " profiles" )
		--print( table.getn(lines) .. " lines" )
		
		for i=1,NumProfiles do
			-- Declare vars
			local Name = ""
			local Global = {}
			local Neutral = {}
			local Maxima = {}
			
			-- Read profile name
			Name = lines[finger]
			finger = finger + 1
			
			-- Read profile values
			finger = finger + 1	-- Skip header
			for j=1,6 do
				Global[j] = tonumber(lines[finger])
				finger = finger + 1
			end
			
			finger = finger + 1	-- Skip header
			for j=1,FlexPoser.Constants.NumAUs do
				Neutral[j] = tonumber(lines[finger])
				finger = finger + 1
			end
			finger = finger + 1	-- Skip header
			for j=1,FlexPoser.Constants.NumAUs do
				Maxima[j] = tonumber(lines[finger])
				finger = finger + 1
			end
			
			-- Store profile
			FlexPoser.Profiles[Name] = {}
			FlexPoser.Profiles[Name].Global = Global
			FlexPoser.Profiles[Name].Neutral = Neutral
			FlexPoser.Profiles[Name].Maxima = Maxima
		end
	end
end

FlexPoser.WriteProfiles = function()
	--print( "FlexPoser: Saving profiles" )
	-- Build name set
	local names={}
	local n=0
	for k,v in pairs(FlexPoser.Profiles) do
		if k != "__Average__" then
			n=n+1
			names[n]=k
		end
	end
	
	-- Prepare file content
	local contents = ""
	
	-- Write number of profiles
	contents = contents .. n .. "\n"
	for i=1,n do
		-- Write profile name
		contents = contents .. names[i] .. "\n"
		
		contents = contents .. "  Globals:\n"
		for j=1,6 do
			contents = contents .. FlexPoser.Profiles[names[i]].Global[j] .. "\n"
		end
		
		-- Write profile values
		contents = contents .. "  Neutral:\n"
		for j=1,FlexPoser.Constants.NumAUs do
			contents = contents .. FlexPoser.Profiles[names[i]].Neutral[j] .. "\n"
		end
		contents = contents .. "  Maxima:\n"
		for j=1,FlexPoser.Constants.NumAUs do
			contents = contents .. FlexPoser.Profiles[names[i]].Maxima[j] .. "\n"
		end
	end
	
	-- Write contents to file
	file.Write( "flexposer_profiles.txt", contents )
end

FlexPoser.AnalyzeProfiles = function()
	--print( "FlexPoser: Analyzing profiles..." )
	
	-- Construct name set
	local names={}
	local n=0
	for k,v in pairs(FlexPoser.Profiles) do
		n=n+1
		names[n]=k
	end
	
	-- Allocate result variables
	local NumProfiles = n
	
	-- Compute average
	local AvgNeutral = {}
	local AvgMaxima = {}
	for i=1,FlexPoser.Constants.NumAUs do
		local SumNeutral = 0
		local SumMaxima = 0
		for j=1,n do
			SumNeutral = SumNeutral + FlexPoser.Profiles[names[j]].Neutral[i]
			SumMaxima = SumMaxima + FlexPoser.Profiles[names[j]].Maxima[i]
		end
		AvgNeutral[i] = SumNeutral / NumProfiles
		AvgMaxima[i] = SumMaxima / NumProfiles
	end
	
	-- Compute variance
	local NeutralVar = {}
	local MaximaVar = {}
	for i=1,FlexPoser.Constants.NumAUs do
		local SumNeutral = 0
		local SumMaxima = 0
		for j=1,n do
			SumNeutral = SumNeutral + (FlexPoser.Profiles[names[j]].Neutral[i] - AvgNeutral[i])^2
			SumMaxima = SumMaxima + (FlexPoser.Profiles[names[j]].Maxima[i] - AvgMaxima[i])^2
		end
		NeutralVar[i] = SumNeutral / NumProfiles
		MaximaVar[i] = SumMaxima / NumProfiles
	end
	
	-- Fix some shit
	for i=1,7 do
		local NeutralAvg = 0.5 * (AvgNeutral[2*i-1] + AvgNeutral[2*i])
		local MaxAvg = 0.5 * (AvgMaxima[2*i-1] + AvgMaxima[2*i])
		AvgNeutral[2*i-1] = NeutralAvg
		AvgNeutral[2*i] = NeutralAvg
		AvgMaxima[2*i-1] = MaxAvg
		AvgMaxima[2*i] = MaxAvg
	end
	
	-- Create __Average__ profile
	local AvgName = "__Average__"
	FlexPoser.Profiles[AvgName] = {}
	FlexPoser.Profiles[AvgName].Neutral = {}
	FlexPoser.Profiles[AvgName].Maxima = {}
	for i=1,FlexPoser.Constants.NumAUs do
		FlexPoser.Profiles[AvgName].Neutral[i] = AvgNeutral[i]
		FlexPoser.Profiles[AvgName].Maxima[i] = AvgMaxima[i]
	end
end