FlexPoser.Menu.CreateAboutPanel = function()
	local sepY1 = 440
	local margin = 10
	
	local AboutPanel = vgui.Create( "DPanel" )
	AboutPanel:SetPaintBackground( false )
	
	-- AUTO CONNECT OPTIONS
	local APanel = vgui.Create( "DPanel", AboutPanel )
	APanel:SetPos( 0, 0 )
	APanel:SetSize( 256, sepY1 )
	
	local texts = {
		"Server is running FlexPoser " .. FlexPoser.Version,
		"",
		"More info: ",
		"    flexposer.com",
		"    zkshao.com (addon author)",
		"    jsaragih.com (face tracking author)",
	}
	
	local contents = table.concat(texts, "\n")
	
	local InfoLabel = vgui.Create( "DLabel", APanel )
	InfoLabel:SetPos( margin, 0 )
	InfoLabel:SetWrap( true )
	InfoLabel:SetSize( 234 - 2 * margin, 120 - 2 * margin )
	InfoLabel:SetText( contents )
	InfoLabel:SetTextColor( Color(0, 0, 0, 255) )
	
	AboutPanel:SizeToContents()
	return AboutPanel
end