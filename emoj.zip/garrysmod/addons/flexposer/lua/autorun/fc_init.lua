-- Create global table
FlexPoser = {}
FlexPoser.Version = "v1.0"
FlexPoser.EnableTracking = true

if SERVER then
	-- Register client side LUA files
	AddCSLuaFile( "fc_init.lua" )
	AddCSLuaFile( "shared_apply_weights.lua" )
	AddCSLuaFile( "shared_constants.lua" )
	AddCSLuaFile( "shared_net.lua" )
	AddCSLuaFile( "cl_preferences.lua" )
	AddCSLuaFile( "cl_profiles.lua" )
	AddCSLuaFile( "cl_status.lua" )
	AddCSLuaFile( "cl_update_animation.lua" )
	AddCSLuaFile( "cl_gui_callbacks.lua" )
	AddCSLuaFile( "cl_gui_setup.lua" )
	AddCSLuaFile( "cl_gui_setup_about.lua" )
	AddCSLuaFile( "cl_gui_setup_main.lua" )
	AddCSLuaFile( "cl_gui_setup_prefs.lua" )
	AddCSLuaFile( "cl_gui_setup_questionnaire.lua" )
	AddCSLuaFile( "cl_preview_setup.lua" )
	AddCSLuaFile( "cl_preview_view.lua" )
	AddCSLuaFile( "cl_wizard_callbacks.lua" )
	AddCSLuaFile( "cl_wizard_setup.lua" )
	AddCSLuaFile( "cl_wizard_view.lua" )
	
	-- Register client side assets
	resource.AddFile( "data/face2.txt" )
	resource.AddFile( "materials/status_failure.png" )
	resource.AddFile( "materials/status_success.png" )
	resource.AddFile( "materials/status_unknown.png" )
	resource.AddFile( "materials/ex1.png" )
	resource.AddFile( "materials/ex2.png" )
	resource.AddFile( "materials/ex3.png" )
	resource.AddFile( "materials/ex4.png" )
	resource.AddFile( "materials/ex5.png" )
	resource.AddFile( "materials/ex6.png" )
	resource.AddFile( "materials/ex7.png" )
	resource.AddFile( "materials/wait.png" )
	resource.AddFile( "sound/ping.wav" )
	resource.AddFile( "sound/shutter_click.wav" )
	
	-- Load server side LUA files
	include( "sha1.lua" )
	include( "tracking.lua" )
	include( "shared_apply_weights.lua" )
	include( "shared_constants.lua" )
	include( "shared_net.lua" )
	
	-- Setup FlexPoser data transfer
	hook.Add( "Initialize", "FC_Setup", FlexPoser.InitNetServer )
	hook.Add( "PlayerInitialSpawn", "FC_UnlockFlexScale", 
		function( ply ) 
			ply:SetFlexScale( 1.8 )
			ply:PrintMessage( HUD_PRINTTALK, "This server supports FlexPoser: Use your webcam to control your character's facial expression. Type !fp or !flexposer to open the GUI." )
		end )
		
	-- Initialize statistics tracking (will be removed entirely from addon after public testing phase)
	hook.Add( "Initialize", "FC_SessionStart", FlexPoser.Tracking.OnSessionStart )
	hook.Add( "ShutDown", "FC_SessionEnd", FlexPoser.Tracking.OnSessionEnd )
	hook.Add( "PlayerInitialSpawn", "FC_PlayerJoined", FlexPoser.Tracking.OnPlayerJoined )
	hook.Add( "PlayerDisconnected", "FC_PlayerLeft", FlexPoser.Tracking.OnPlayerLeft )	
elseif CLIENT then
	-- Load client side LUA files
	include( "shared_apply_weights.lua" )
	include( "shared_constants.lua" )
	include( "shared_net.lua" )
	include( "cl_preferences.lua" )
	include( "cl_profiles.lua" )
	include( "cl_status.lua" )
	include( "cl_update_animation.lua" )
	include( "cl_gui_setup.lua" )
	include( "cl_gui_callbacks.lua" )
	include( "cl_gui_setup_about.lua" )
	include( "cl_gui_setup_main.lua" )
	include( "cl_gui_setup_prefs.lua" )
	include( "cl_gui_setup_questionnaire.lua" )
	include( "cl_preview_setup.lua" )
	include( "cl_preview_view.lua" )
	include( "cl_wizard_setup.lua" )
	include( "cl_wizard_callbacks.lua" )
	include( "cl_wizard_view.lua" )
	
	FlexPoser.OpenMenu = function()
		FlexPoser.Menu.Frame:SetVisible( true )
		FlexPoser.Menu.Frame:MakePopup()
	end

	-- Define initialization process
	FlexPoser.Init = function()
		FlexPoser.ReadProfiles()		-- Read stored profiles from file
		FlexPoser.ReadPreferences()		-- Read stored preferences from file

		FlexPoser.Menu.Create()			-- Create menu GUI
		FlexPoser.Wizard.Create()		-- Create wizard GUI
		FlexPoser.Preview.Create()		-- Create preview panel
		
		FlexPoser.InitNetClient()		-- Setup network messaging
		
		-- Apply read preferences
		FlexPoser.Preview.Reposition()	
		if FlexPoser.Preferences.AutoConnect then
			-- Try to auto-load profile
			local lastProfileName = FlexPoser.Preferences.LastProfile
			if FlexPoser.Profiles[ lastProfileName ] != nil then
				FlexPoser.Status.Profile = true
				FlexPoser.Status.ProfileName = FlexPoser.Preferences.LastProfile
			end
		
			-- Simulate enable button
			FlexPoser.Menu.EnableButtonHandler()
		end
		
		-- Set initial status icons and menu panel
		FlexPoser.UpdateStatus()
		
		-- Show the menu and create a console command to show menu
		FlexPoser.Menu.Frame:SetVisible( FlexPoser.Preferences.AutoShow )
		concommand.Add( "fp_openmenu", FlexPoser.OpenMenu )
	end
	
	-- Define shutdown process
	FlexPoser.Exit = function()
		concommand.Remove( "fp_openmenu" )
	
		-- Note: Profiles and preferences are also stored whenever a change occurs
		FlexPoser.WriteProfiles()
		FlexPoser.WritePreferences()
	end
	
	-- Define chat command listener
	FlexPoser.ChatHandler = function( ply, txt, teamChat, isDead )
		if ply == LocalPlayer() then
			local txtLower = string.lower(txt)
			if txtLower == "!fp" || txtLower == "!flexposer" then
				FlexPoser.OpenMenu()
			end
		end
	end
	
	hook.Add( "Initialize", "FC_Init", FlexPoser.Init )						-- Addon startup stuff
	hook.Add( "OnPlayerChat", "FC_OpenMenu", FlexPoser.ChatHandler )	-- Open menu when local player types "!fc"
	hook.Add( "UpdateAnimation", "FC_UpdateFace", FlexPoser.UpdateFace )	-- Update local player's face periodically
	hook.Add( "ShutDown", "FC_Exit", FlexPoser.Exit )						-- Addon exit stuff
end