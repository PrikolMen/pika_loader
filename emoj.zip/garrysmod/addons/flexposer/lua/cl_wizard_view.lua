-- Opens the wizard
FlexPoser.Wizard.Open = function( name, exists )
	-- Create new process info
	FlexPoser.Wizard.Process.Name = name
	FlexPoser.Wizard.Process.Neutral = {}	-- Neutral pose values
	FlexPoser.Wizard.Process.Minima = {}	-- Values that represent flex weight 0
	FlexPoser.Wizard.Process.Maxima = {}	-- Values that represent flex weight 1
	
	-- Go to page 1
	FlexPoser.Wizard.Goto( 1 )
	
	-- Show frame
	FlexPoser.Wizard.TipsFrame:SetVisible( true )
	FlexPoser.Wizard.Frame:SetVisible( true )
	FlexPoser.Wizard.Frame:MakePopup()
end

FlexPoser.Wizard.Close = function()
	-- Hide window
	FlexPoser.Wizard.NameEntry.Frame:SetVisible( false )
	FlexPoser.Wizard.TipsFrame:SetVisible( false )
	FlexPoser.Wizard.Frame:SetVisible( false )
	
	-- Remove update callbacks
	__StopMinMax()
	hook.Remove( "Think", "FC_PollCalibrate" )
end

-- Go to a page, hides current page
FlexPoser.Wizard.Goto = function( PageID )
	-- Hide current page
	FlexPoser.Wizard.Page:SetVisible( false )
	
	-- Perform enter page callback
	FlexPoser.Wizard.EnterPageCallback( PageID )
	
	-- Show and store next page
	FlexPoser.Wizard.PageID = PageID
	FlexPoser.Wizard.Page = FlexPoser.Wizard.Pages[PageID]
	FlexPoser.Wizard.Page:SetVisible( true )
end

-- Handles back button clicked
FlexPoser.Wizard.BackHandler = function()
	-- Switch page
	local PageID = FlexPoser.Wizard.PageID
	if PageID == 1 then
		-- Go to "Tips" screen
		FlexPoser.Wizard.Goto( 11 )
	elseif PageID == 11 then
		-- Go back to face detection screen
		FlexPoser.Wizard.Goto( 1 )
	elseif PageID == 10 then
		-- Go back to neutral snap screen
		FlexPoser.Wizard.Goto( 2 )
	elseif PageID - 1 >= 1 then
		-- Go to previous page
		FlexPoser.Wizard.Goto( PageID - 1 )
	end
end

-- Handles next button clicked
FlexPoser.Wizard.NextHandler = function()
	-- Perform exit page callback
	local PageID = FlexPoser.Wizard.PageID
	FlexPoser.Wizard.ExitPageCallback( PageID )
	
	if FlexPoser.Wizard.PageID == 10 then
		-- Close wizard
		FlexPoser.Wizard.TipsFrame:SetVisible( false )
		FlexPoser.Wizard.Frame:SetVisible( false )
	else
		-- Go to next page
		FlexPoser.Wizard.Goto( PageID + 1 )
	end
end