if CLIENT then

	g_VR = g_VR or {}
	g_VR.characterYaw = 0
	g_VR.characterWalkX = 0
	g_VR.characterWalkY = 0
	g_VR.characterInfo = {}
	
	--todo calculate these angles for better compatibility
	--todo each player needs to have their own for multiplayer
	g_VR.defaultOpenHandAngles = {
		--left hand
		Angle(0,0,0), Angle(0,-40,0), Angle(0,0,0), --finger 0
		Angle(0,30,0), Angle(0,10,0), Angle(0,0,0), --finger 1
		Angle(0,30,0), Angle(0,10,0), Angle(0,0,0), --finger 2
		Angle(0,30,0), Angle(0,10,0), Angle(0,0,0), --finger 3
		Angle(0,30,0), Angle(0,10,0), Angle(0,0,0), --finger 4
		--right hand
		Angle(0,0,0), Angle(0,-40,0), Angle(0,0,0),
		Angle(0,30,0), Angle(0,10,0), Angle(0,0,0),
		Angle(0,30,0), Angle(0,10,0), Angle(0,0,0),
		Angle(0,30,0), Angle(0,10,0), Angle(0,0,0),
		Angle(0,30,0), Angle(0,10,0), Angle(0,0,0),
	}
	
	g_VR.defaultClosedHandAngles = {
		Angle(30,0,0), Angle(0,0,0), Angle(0,30,0),
		Angle(0,-50,-10), Angle(0,-90,0), Angle(0,-70,0),
		Angle(0,-35.-8,0), Angle(0,-80,0), Angle(0,-70,0),
		Angle(0,-26.5,4.8), Angle(0,-70,0), Angle(0,-70,0),
		Angle(0,-30,12.7), Angle(0,-70,0), Angle(0,-70,0),
		--
		Angle(-30,0,0), Angle(0,0,0), Angle(0,30,0),
		Angle(0,-50,10), Angle(0,-90,0), Angle(0,-70,0),
		Angle(0,-35.8,0), Angle(0,-80,0), Angle(0,-70,0),
		Angle(0,-26.5,-4.8), Angle(0,-70,0), Angle(0,-70,0),
		Angle(0,-30,-12.7), Angle(0,-70,0), Angle(0,-70,0),
	}
	
	g_VR.zeroHandAngles = {
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
		Angle(0,0,0), Angle(0,0,0), Angle(0,0,0),
	}
	
	g_VR.openHandAngles = g_VR.defaultOpenHandAngles
	g_VR.closedHandAngles = g_VR.defaultClosedHandAngles

	local function RecursiveBoneTable2(ent, parentbone, infotab, ordertab, notfirst)
		local bones = notfirst and ent:GetChildBones(parentbone) or {parentbone}
		for k,v in pairs(bones) do
			local n = ent:GetBoneName(v)
			local boneparent = ent:GetBoneParent(v)
			local parentmat = ent:GetBoneMatrix(boneparent) --getboneposition doesnt work for all bones! but matrix seems to
			local childmat = ent:GetBoneMatrix(v)
			local parentpos, parentang = parentmat:GetTranslation(), parentmat:GetAngles()
			local childpos, childang = childmat:GetTranslation(), childmat:GetAngles()
			local relpos, relang = WorldToLocal(childpos, childang, parentpos, parentang)
			infotab[v] = {name = n, pos = Vector(0,0,0), ang = Angle(0,0,0), parent = boneparent, relativePos = relpos, relativeAng = relang, offsetAng = Angle(0,0,0)}
			ordertab[#ordertab+1] = v
		end
		for k,v in pairs(bones) do
			RecursiveBoneTable2(ent, v, infotab, ordertab, true)
		end
	end
	

	local characterHeadToHmdDist = 0
	local characterEyeHeight = 0

	function VRUtilCharacterInit(ply)
		local steamid = ply:SteamID()
		
		if ply == LocalPlayer() then
			timer.Create("vrutil_timer_validatefingertracking",0.1,0,function()
				if g_VR.tracking.pose_lefthand and g_VR.tracking.pose_righthand then
					timer.Remove("vrutil_timer_validatefingertracking")
					for i = 1,2 do
						for k,v in pairs(i==1 and g_VR.input.skeleton_lefthand.fingerCurls or g_VR.input.skeleton_righthand.fingerCurls) do
							if v < 0 or v > 1 or (k==3 and v == 0.75) then
								g_VR.defaultOpenHandAngles = g_VR.zeroHandAngles
								g_VR.defaultClosedHandAngles = g_VR.zeroHandAngles
								g_VR.openHandAngles = g_VR.zeroHandAngles
								g_VR.closedHandAngles = g_VR.zeroHandAngles
								break
							end
						end
					end
				end
			end)
		end
		
		--add characterInfo entry
		g_VR.characterInfo[steamid] = {
			preRenderPos = Vector(0,0,0),
			renderPos = Vector(0,0,0),
			characterHeadToHmdDist = 0,
			characterEyeHeight = 0,
			bones = {},
			boneinfo = {},
			boneorder = {},
			player = ply,
			boneCallback = 0,
			verticalCrouchOffset = 0,
			horizontalCrouchOffset = 0
		}
		
		ply:SetLOD(0)
		

		
		--create temporary clientside clone for taking measurements
		
		local cm = ClientsideModel(ply:GetModel())
		cm:SetPos(LocalPlayer():GetPos())
		cm:SetAngles(Angle(0,0,0))
		cm:SetupBones()
		
		RecursiveBoneTable2(cm, cm:LookupBone("ValveBiped.Bip01_L_Clavicle"), g_VR.characterInfo[steamid].boneinfo, g_VR.characterInfo[steamid].boneorder)
		RecursiveBoneTable2(cm, cm:LookupBone("ValveBiped.Bip01_R_Clavicle"), g_VR.characterInfo[steamid].boneinfo, g_VR.characterInfo[steamid].boneorder)
		
		local boneNames = {
			b_leftClavicle = "ValveBiped.Bip01_L_Clavicle",
			b_leftUpperarm = "ValveBiped.Bip01_L_UpperArm",
			b_leftForearm = "ValveBiped.Bip01_L_Forearm",
			b_leftHand = "ValveBiped.Bip01_L_Hand",
			b_leftWrist = "ValveBiped.Bip01_L_Wrist",
			b_leftUlna = "ValveBiped.Bip01_L_Ulna",
			b_leftCalf = "ValveBiped.Bip01_L_Calf",
			b_leftThigh = "ValveBiped.Bip01_L_Thigh",
			b_leftFoot = "ValveBiped.Bip01_L_Foot",
			b_rightClavicle = "ValveBiped.Bip01_R_Clavicle",
			b_rightUpperarm = "ValveBiped.Bip01_R_UpperArm",
			b_rightForearm = "ValveBiped.Bip01_R_Forearm",
			b_rightHand = "ValveBiped.Bip01_R_Hand",
			b_rightWrist = "ValveBiped.Bip01_R_Wrist",
			b_rightUlna = "ValveBiped.Bip01_R_Ulna",
			b_rightCalf = "ValveBiped.Bip01_R_Calf",
			b_rightThigh = "ValveBiped.Bip01_R_Thigh",
			b_rightFoot = "ValveBiped.Bip01_R_Foot",
			b_head = "ValveBiped.Bip01_Head1",
			b_spine = "ValveBiped.Bip01_Spine",
		}
		g_VR.characterInfo[steamid].bones = {
			fingers = {
				cm:LookupBone("ValveBiped.Bip01_L_Finger0") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger01") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger02") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger1") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger11") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger12") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger2") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger21") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger22") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger3") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger31") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger32") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger4") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger41") or -1,
				cm:LookupBone("ValveBiped.Bip01_L_Finger42") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger0") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger01") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger02") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger1") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger11") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger12") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger2") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger21") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger22") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger3") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger31") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger32") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger4") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger41") or -1,
				cm:LookupBone("ValveBiped.Bip01_R_Finger42") or -1,
			}
		}
		
		if ply == LocalPlayer() then
			g_VR.errorText = ""
		end
		
		for k,v in pairs(boneNames) do
			local bone = cm:LookupBone(v) or -1
			g_VR.characterInfo[steamid].bones[k] = bone
			if bone == -1 and not string.find(k,"Wrist") and not string.find(k,"Ulna") then
				if ply == LocalPlayer() then
					g_VR.errorText = "Incompatible player model. Missing bone "..v
				end
				cm:Remove()
				VRUtilCharacterCleanup(ply:SteamID())
				return
			end
		end
		
		local claviclePos = cm:GetBonePosition(g_VR.characterInfo[steamid].bones.b_leftClavicle)
		local upperPos = cm:GetBonePosition(g_VR.characterInfo[steamid].bones.b_leftUpperarm)
		local lowerPos = cm:GetBonePosition(g_VR.characterInfo[steamid].bones.b_leftForearm)
		local handPos = cm:GetBonePosition(g_VR.characterInfo[steamid].bones.b_leftHand)
		local thighPos = cm:GetBonePosition(g_VR.characterInfo[steamid].bones.b_leftThigh)
		local calfPos = cm:GetBonePosition(g_VR.characterInfo[steamid].bones.b_leftCalf)
		local footPos = cm:GetBonePosition(g_VR.characterInfo[steamid].bones.b_leftFoot)
		local headPos = cm:GetBonePosition(g_VR.characterInfo[steamid].bones.b_head)
		local spinePos = cm:GetBonePosition(g_VR.characterInfo[steamid].bones.b_spine)
		
		g_VR.characterInfo[steamid].clavicleLen = claviclePos:Distance(upperPos)
		g_VR.characterInfo[steamid].upperArmLen = upperPos:Distance(lowerPos)
		g_VR.characterInfo[steamid].lowerArmLen = lowerPos:Distance(handPos)
		g_VR.characterInfo[steamid].upperLegLen = thighPos:Distance(calfPos)
		g_VR.characterInfo[steamid].lowerLegLen = calfPos:Distance(footPos)
		--spineLen is set after eye height
		
		--
		local eyes = cm:GetAttachment(cm:LookupAttachment("eyes"))
		if eyes then 
			eyes.Pos = eyes.Pos - cm:GetPos() 
		end
		if eyes and eyes.Pos.z > 10 then --assume eye pos is valid if its above ground
			g_VR.characterInfo[steamid].characterEyeHeight = eyes.Pos.z
			g_VR.characterInfo[steamid].characterHeadToHmdDist = eyes.Pos.x * 2
		else --otherwise set some ballparks
			headPos = headPos - cm:GetPos()
			g_VR.characterInfo[steamid].characterEyeHeight = headPos.z
			g_VR.characterInfo[steamid].characterHeadToHmdDist = 7
		end
		
		g_VR.characterInfo[steamid].spineLen = (cm:GetPos().z + g_VR.characterInfo[steamid].characterEyeHeight) - spinePos.z
		
		--if this is the localplayer, set VR scale so that userheight*scale = characterEyeHeight
		if ply == LocalPlayer() then
			local userHeight = (GetConVar("vrutil_userheight"):GetInt() - 13) / 100
			g_VR.scale = g_VR.characterInfo[steamid].characterEyeHeight/userHeight
		end
		
		cm:Remove()
		
		--**************************
		g_VR.characterInfo[steamid].boneCallback = ply:AddCallback("BuildBonePositions",function(ply)
			local steamid = ply:SteamID()
			if not g_VR.net[steamid] or not g_VR.net[steamid].lerpedFrame or ply:InVehicle() then return end
			ply:SetBonePosition(g_VR.characterInfo[steamid].bones.b_rightHand, g_VR.net[steamid].lerpedFrame.righthandPos, g_VR.net[steamid].lerpedFrame.righthandAng + Angle(0,0,180))
		end)
		
		
		--if this is the local player and first person body is hidden, calculate the players would-be render position here so the locomotion system can know where the player should be
		--normally its done in predrawplayer but that wont be called if the player isnt visible
		if ply == LocalPlayer() and GetConVar("vrutil_hidecharacter"):GetBool() then
			hook.Add("Think","vrutil_hook_calcplyrenderpos",function()
				if not g_VR.net[steamid] or not g_VR.net[steamid].lerpedFrame then return end
				g_VR.characterInfo[steamid].renderPos = g_VR.net[steamid].lerpedFrame.hmdPos + Angle(0,g_VR.net[steamid].lerpedFrame.hmdAng.yaw,0):Forward()*-g_VR.characterInfo[steamid].characterHeadToHmdDist + Angle(0,g_VR.net[steamid].lerpedFrame.characterYaw,0):Forward()*-g_VR.characterInfo[steamid].horizontalCrouchOffset*0.8
				g_VR.characterInfo[steamid].renderPos.z = g_VR.net[steamid].lerpedFrame.originHeight - g_VR.characterInfo[steamid].verticalCrouchOffset
			end)
		end
		
		hook.Add("PrePlayerDraw","vrutil_hook_preplayerdraw",function(ply)
			local steamid = ply:SteamID()
			if not g_VR.net[steamid] or not g_VR.net[steamid].lerpedFrame or ( ply:InVehicle() and ply:GetVehicle():GetClass() ~= "prop_vehicle_prisoner_pod" ) then return end
			
			g_VR.characterInfo[steamid].preRenderPos = ply:GetPos()
			if not ply:InVehicle() then
				g_VR.characterInfo[steamid].renderPos = g_VR.net[steamid].lerpedFrame.hmdPos + Angle(0,g_VR.net[steamid].lerpedFrame.hmdAng.yaw,0):Forward()*-g_VR.characterInfo[steamid].characterHeadToHmdDist + Angle(0,g_VR.net[steamid].lerpedFrame.characterYaw,0):Forward()*-g_VR.characterInfo[steamid].horizontalCrouchOffset*0.8
				g_VR.characterInfo[steamid].renderPos.z = g_VR.net[steamid].lerpedFrame.originHeight - g_VR.characterInfo[steamid].verticalCrouchOffset
				ply:SetPos(g_VR.characterInfo[steamid].renderPos)
				ply:SetRenderAngles(Angle(0,g_VR.net[steamid].lerpedFrame.characterYaw,0))
			end
			
			if ply == LocalPlayer() then
				local ep = EyePos()
				ply:ManipulateBoneScale(ply:LookupBone("ValveBiped.Bip01_Head1"), (ep == g_VR.eyePosLeft or ep == g_VR.eyePosRight) and Vector(0,0,0) or Vector(1,1,1))
			end
			
			ply:SetupBones()
			
			--****************** LEFT SIDE ******************
			local L_TargetPos = g_VR.net[steamid].lerpedFrame.lefthandPos
			local L_TargetAng = g_VR.net[steamid].lerpedFrame.lefthandAng
			local L_ClaviclePos = ply:GetBoneMatrix(g_VR.characterInfo[steamid].bones.b_leftClavicle):GetTranslation()
			--Calculate LEFT clavicle target angle
			local tmp1 = L_ClaviclePos + Angle(0,g_VR.net[steamid].lerpedFrame.characterYaw+90,0):Forward()*g_VR.characterInfo[steamid].clavicleLen --neutral shoulder position
			local tmp2 = tmp1 + (L_TargetPos-tmp1)*0.15 --desired shoulder position
			local L_ClavicleTargetAng = (tmp2-L_ClaviclePos):Angle()
			L_ClavicleTargetAng:RotateAroundAxis(L_ClavicleTargetAng:Forward(),90)
			----------
			local L_UpperarmPos = L_ClaviclePos + L_ClavicleTargetAng:Forward()*g_VR.characterInfo[steamid].clavicleLen
			local L_TargetVec = (L_TargetPos)-L_UpperarmPos
			local L_TargetVecLen = L_TargetVec:Length()
			local L_TargetVecAng = L_TargetVec:Angle()
			
			--Calculate LEFT upperarm target angle
			local L_UpperarmTargetAng = Angle(L_TargetVecAng.pitch,L_TargetVecAng.yaw, L_TargetVecAng.roll) --copy to avoid weirdness
			local tmp = Angle(L_TargetVecAng.pitch, g_VR.net[steamid].lerpedFrame.characterYaw, -90)
			local tpos, tang = WorldToLocal(Vector(0,0,0),tmp,Vector(0,0,0),L_TargetVecAng)
			L_UpperarmTargetAng:RotateAroundAxis(L_UpperarmTargetAng:Forward(),tang.roll)
			local a1 = math.deg(math.acos( (g_VR.characterInfo[steamid].upperArmLen*g_VR.characterInfo[steamid].upperArmLen + L_TargetVecLen*L_TargetVecLen - g_VR.characterInfo[steamid].lowerArmLen*g_VR.characterInfo[steamid].lowerArmLen) / (2*g_VR.characterInfo[steamid].upperArmLen*L_TargetVecLen) ))
			if a1 == a1 then
				L_UpperarmTargetAng:RotateAroundAxis(L_UpperarmTargetAng:Up(),a1)
			end
			local test = ((L_TargetPos.z - (L_UpperarmPos.z)) + 20) *1.5
			if test < 0 then
				test = 0
			end
			L_UpperarmTargetAng:RotateAroundAxis(L_TargetVec:GetNormalized(),30 + test)
			
			--Calculate LEFT forearm target angle
			local L_ForearmTargetAng = Angle(L_UpperarmTargetAng.pitch,L_UpperarmTargetAng.yaw, L_UpperarmTargetAng.roll)
			local a23 = 180 - a1 - math.deg(math.acos( (g_VR.characterInfo[steamid].lowerArmLen*g_VR.characterInfo[steamid].lowerArmLen + L_TargetVecLen*L_TargetVecLen - g_VR.characterInfo[steamid].upperArmLen*g_VR.characterInfo[steamid].upperArmLen) / (2*g_VR.characterInfo[steamid].lowerArmLen*L_TargetVecLen) ))
			if a23 == a23 then
				L_ForearmTargetAng:RotateAroundAxis(L_ForearmTargetAng:Up(),180+a23)
			end
			
			--Calculate LEFT wrist and ulna angle
			local tmp = Angle(L_TargetAng.pitch, L_TargetAng.yaw, L_TargetAng.roll - 90)
			local tpos, tang = WorldToLocal(Vector(0,0,0),tmp,Vector(0,0,0),L_ForearmTargetAng)
			local L_WristTargetAng = Angle(L_ForearmTargetAng.pitch, L_ForearmTargetAng.yaw, L_ForearmTargetAng.roll)
			L_WristTargetAng:RotateAroundAxis(L_WristTargetAng:Forward(),tang.roll)
			local L_UlnaTargetAng = LerpAngle(0.5,L_ForearmTargetAng,L_WristTargetAng)
			
			
			--****************** RIGHT SIDE ******************
			local R_TargetPos = g_VR.net[steamid].lerpedFrame.righthandPos
			local R_TargetAng = g_VR.net[steamid].lerpedFrame.righthandAng
			local R_ClaviclePos = ply:GetBoneMatrix(g_VR.characterInfo[steamid].bones.b_rightClavicle):GetTranslation()
			--Calculate RIGHT clavicle target angle
			local tmp1 = R_ClaviclePos + Angle(0,g_VR.net[steamid].lerpedFrame.characterYaw-90,0):Forward()*g_VR.characterInfo[steamid].clavicleLen
			local tmp2 = tmp1 + (R_TargetPos-tmp1)*0.15
			local R_ClavicleTargetAng = (tmp2-R_ClaviclePos):Angle()
			R_ClavicleTargetAng:RotateAroundAxis(R_ClavicleTargetAng:Forward(),90)
			----------
			local R_UpperarmPos = R_ClaviclePos + R_ClavicleTargetAng:Forward()*g_VR.characterInfo[steamid].clavicleLen
			local R_TargetVec = (R_TargetPos)-R_UpperarmPos
			local R_TargetVecLen = R_TargetVec:Length()
			local R_TargetVecAng = R_TargetVec:Angle()
			
			--Calculate RIGHT upperarm target angle
			local R_UpperarmTargetAng = Angle(R_TargetVecAng.pitch,R_TargetVecAng.yaw, 180)
			local tmp = Angle(R_TargetVecAng.pitch, g_VR.net[steamid].lerpedFrame.characterYaw, 90)
			local tpos, tang = WorldToLocal(Vector(0,0,0),tmp,Vector(0,0,0),R_TargetVecAng)
			R_UpperarmTargetAng:RotateAroundAxis(R_UpperarmTargetAng:Forward(),tang.roll)
			local a1 = math.deg(math.acos( (g_VR.characterInfo[steamid].upperArmLen*g_VR.characterInfo[steamid].upperArmLen + R_TargetVecLen*R_TargetVecLen - g_VR.characterInfo[steamid].lowerArmLen*g_VR.characterInfo[steamid].lowerArmLen) / (2*g_VR.characterInfo[steamid].upperArmLen*R_TargetVecLen) ))
			if a1 == a1 then
				R_UpperarmTargetAng:RotateAroundAxis(R_UpperarmTargetAng:Up(),a1)
			end
			local test = ((R_TargetPos.z - (R_UpperarmPos.z)) + 20) *1.5
			if test < 0 then
				test = 0
			end
			R_UpperarmTargetAng:RotateAroundAxis(R_TargetVec:GetNormalized(),-(30 + test))
			
			--Calculate RIGHT forearm target angle
			local R_ForearmTargetAng = Angle(R_UpperarmTargetAng.pitch,R_UpperarmTargetAng.yaw, R_UpperarmTargetAng.roll)
			local a23 = 180 - a1 - math.deg(math.acos( (g_VR.characterInfo[steamid].lowerArmLen*g_VR.characterInfo[steamid].lowerArmLen + R_TargetVecLen*R_TargetVecLen - g_VR.characterInfo[steamid].upperArmLen*g_VR.characterInfo[steamid].upperArmLen) / (2*g_VR.characterInfo[steamid].lowerArmLen*R_TargetVecLen) ))
			if a23 == a23 then
				R_ForearmTargetAng:RotateAroundAxis(R_ForearmTargetAng:Up(),180+a23)
			end
			
			--Calculate RIGHT wrist and ulna angle
			local tmp = Angle(R_TargetAng.pitch, R_TargetAng.yaw, R_TargetAng.roll - 90)
			local tpos, tang = WorldToLocal(Vector(0,0,0),tmp,Vector(0,0,0),R_ForearmTargetAng)
			local R_WristTargetAng = Angle(R_ForearmTargetAng.pitch, R_ForearmTargetAng.yaw, R_ForearmTargetAng.roll)
			R_WristTargetAng:RotateAroundAxis(R_WristTargetAng:Forward(),tang.roll)
			local R_UlnaTargetAng = LerpAngle(0.5,R_ForearmTargetAng,R_WristTargetAng)
			
			--set absolute override angles for the relevant bones
			g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_leftClavicle].overrideAng = L_ClavicleTargetAng
			g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_leftUpperarm].overrideAng = L_UpperarmTargetAng
			g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_leftHand].overrideAng = L_TargetAng
			g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_rightClavicle].overrideAng = R_ClavicleTargetAng
			g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_rightUpperarm].overrideAng = R_UpperarmTargetAng
			g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_rightHand].overrideAng = R_TargetAng + Angle(0,0,180)
			if g_VR.characterInfo[steamid].bones.b_leftWrist and g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_leftWrist] and g_VR.characterInfo[steamid].bones.b_leftUlna and g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_leftUlna] then
				g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_leftForearm].overrideAng = L_ForearmTargetAng
				g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_leftWrist].overrideAng = L_WristTargetAng
				g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_leftUlna].overrideAng = L_UlnaTargetAng
				g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_rightForearm].overrideAng = R_ForearmTargetAng
				g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_rightWrist].overrideAng = R_WristTargetAng
				g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_rightUlna].overrideAng = R_UlnaTargetAng
			else
				g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_leftForearm].overrideAng = L_UlnaTargetAng
				g_VR.characterInfo[steamid].boneinfo[g_VR.characterInfo[steamid].bones.b_rightForearm].overrideAng = R_UlnaTargetAng
			end
			
			--set finger offset angles
			for k,v in pairs(g_VR.characterInfo[steamid].bones.fingers) do
				if not g_VR.characterInfo[steamid].boneinfo[v] then continue end
				g_VR.characterInfo[steamid].boneinfo[v].offsetAng = LerpAngle(g_VR.net[steamid].lerpedFrame["finger"..math.floor((k-1)/3+1)], g_VR.openHandAngles[k], g_VR.closedHandAngles[k])
			end

			
			--manipulate arms
			for i = 1,#g_VR.characterInfo[steamid].boneorder do
				local bone = g_VR.characterInfo[steamid].boneorder[i]
				local parent = g_VR.characterInfo[steamid].boneinfo[bone].parent
				local wpos, wang
				if g_VR.characterInfo[steamid].boneinfo[bone].name == "ValveBiped.Bip01_L_Clavicle" then
					wpos = L_ClaviclePos
				elseif g_VR.characterInfo[steamid].boneinfo[bone].name == "ValveBiped.Bip01_R_Clavicle" then
					wpos = R_ClaviclePos
				else
					local parentPos, parentAng = g_VR.characterInfo[steamid].boneinfo[parent].pos, g_VR.characterInfo[steamid].boneinfo[parent].ang
					wpos, wang = LocalToWorld(g_VR.characterInfo[steamid].boneinfo[bone].relativePos, g_VR.characterInfo[steamid].boneinfo[bone].relativeAng + g_VR.characterInfo[steamid].boneinfo[bone].offsetAng, parentPos, parentAng)
				end
				if g_VR.characterInfo[steamid].boneinfo[bone].overrideAng ~= nil then
					wang = g_VR.characterInfo[steamid].boneinfo[bone].overrideAng
				end
				local mat = Matrix()
				mat:Translate(wpos)
				mat:Rotate(wang)
				ply:SetBoneMatrix(bone,mat)
				g_VR.characterInfo[steamid].boneinfo[bone].pos = wpos
				g_VR.characterInfo[steamid].boneinfo[bone].ang = wang
			end
			
			--head
			if not g_VR.net[steamid].characterAltHead then
				local unused,targetAng = LocalToWorld(Vector(0,0,0),Angle(-80,0,90),Vector(0,0,0),g_VR.net[steamid].lerpedFrame.hmdAng)
				local mat = ply:GetBoneMatrix(g_VR.characterInfo[steamid].bones.b_head)
				mat:SetAngles(targetAng)
				ply:SetBoneMatrix(g_VR.characterInfo[steamid].bones.b_head,mat)
			end

			return false
		end)
		
		hook.Add("PostPlayerDraw","vrutil_hook_postplayerdraw",function(ply)
			local steamid = ply:SteamID()
			if not g_VR.net[steamid] or not g_VR.net[steamid].lerpedFrame or ply:InVehicle() then return end
			ply:SetPos(g_VR.characterInfo[steamid].preRenderPos)
		end)
		
		hook.Add("Think","vrutil_hook_characterthink",function() --all regular bone manipulation is done here
			for k,v in pairs(g_VR.characterInfo) do
				if not g_VR.net[k].lerpedFrame or not IsValid(v.player) then continue end
				
				if not v.player:InVehicle() then
					local headHeight = g_VR.net[k].lerpedFrame.hmdPos.z + (g_VR.net[k].lerpedFrame.hmdAng:Forward()*-v.characterHeadToHmdDist).z
					local cutAmount = math.Clamp(g_VR.net[k].lerpedFrame.originHeight+v.characterEyeHeight - headHeight,0,40)
					--spine
					local spineTargetLen = v.spineLen - cutAmount*0.5
					local a1 = math.acos(spineTargetLen/v.spineLen)
					g_VR.characterInfo[k].horizontalCrouchOffset = math.sin(a1) * v.spineLen
					v.player:ManipulateBoneAngles(v.bones.b_spine, Angle(0,math.deg(a1),0))
					--legs
					v.verticalCrouchOffset = cutAmount*0.5
					local legTargetLen = v.upperLegLen+v.lowerLegLen - v.verticalCrouchOffset*0.8 --actually cut slightly less or it looks like the legs float with the idle anim
					local a1 = math.deg(math.acos( (v.upperLegLen*v.upperLegLen + legTargetLen*legTargetLen - v.lowerLegLen*v.lowerLegLen) / (2*v.upperLegLen*legTargetLen) ))
					local a23 = 180 - a1 - math.deg(math.acos( (v.lowerLegLen*v.lowerLegLen + legTargetLen*legTargetLen - v.upperLegLen*v.upperLegLen) / (2*v.lowerLegLen*legTargetLen) ))
					if a1 ~= a1 or a23 ~= a23 then
						a1 = 0
						a23 = 180
					end
					v.player:ManipulateBoneAngles( v.bones.b_leftCalf, Angle(0,-(a23-180),0) )
					v.player:ManipulateBoneAngles( v.bones.b_leftThigh, Angle(0,-a1,0) )
					v.player:ManipulateBoneAngles( v.bones.b_rightCalf, Angle(0,-(a23-180),0) )
					v.player:ManipulateBoneAngles( v.bones.b_rightThigh, Angle(0,-a1,0) )
					v.player:ManipulateBoneAngles( v.bones.b_leftFoot, Angle(0,(-a1),0) )
					v.player:ManipulateBoneAngles( v.bones.b_rightFoot, Angle(0,(-a1),0) )
				else
					v.player:ManipulateBoneAngles( v.bones.b_spine, Angle(0,0,0))
					v.player:ManipulateBoneAngles( v.bones.b_leftCalf, Angle(0,0,0) )
					v.player:ManipulateBoneAngles( v.bones.b_leftThigh, Angle(0,0,0) )
					v.player:ManipulateBoneAngles( v.bones.b_rightCalf, Angle(0,0,0) )
					v.player:ManipulateBoneAngles( v.bones.b_rightThigh, Angle(0,0,0) )
					v.player:ManipulateBoneAngles( v.bones.b_leftFoot, Angle(0,0,0) )
					v.player:ManipulateBoneAngles( v.bones.b_rightFoot, Angle(0,0,0) )
				end
				
				--head
				if g_VR.net[k].characterAltHead then
					local tmp1, tmp2 = WorldToLocal(Vector(0,0,0),g_VR.net[k].lerpedFrame.hmdAng,Vector(0,0,0),Angle(0,g_VR.net[k].lerpedFrame.characterYaw,0))
					v.player:ManipulateBoneAngles( v.bones.b_head, Angle(-tmp2.roll,-tmp2.pitch,tmp2.yaw) )
				end
				
			end
			
		end)
		
		--if we're using weapon world models, use this method to show the local player (it will also show the worldmodel, and normally would stop rendering the viewmodel)
		if ply == LocalPlayer() and GetConVar("vrutil_useworldmodels"):GetBool() then
			hook.Add( "ShouldDrawLocalPlayer" , "vrutil_hook_cshoulddrawlocalplayer" , function( ply )
				return true
			end )
		end
		
		
		local previousOriginYaw = g_VR.originYaw
		
		hook.Add( "UpdateAnimation" , "vrutil_hook_updateanimation" , function( ply , vel )
			local steamid = ply:SteamID()
			if not g_VR.net[steamid] or not g_VR.net[steamid].lerpedFrame then return end
			if ply == LocalPlayer() and g_VR.threePoints then
				--character yaw
				local unused, relativeAng = WorldToLocal(Vector(0,0,0),Angle(0,g_VR.tracking.hmd.ang.yaw,0),Vector(0,0,0),Angle(0,g_VR.characterYaw,0))
				if  relativeAng.yaw > 45 then
					g_VR.characterYaw = g_VR.characterYaw + relativeAng.yaw - 45
				elseif relativeAng.yaw < -45 then
					g_VR.characterYaw = g_VR.characterYaw + relativeAng.yaw + 45
				end
				if g_VR.originYaw ~= previousOriginYaw then
					previousOriginYaw = g_VR.originYaw
					g_VR.characterYaw = g_VR.tracking.hmd.ang.yaw
				end
				if g_VR.input.boolean_walk or g_VR.input.boolean_turnleft or g_VR.input.boolean_turnright then
					g_VR.characterYaw = g_VR.tracking.hmd.ang.yaw
				end
				--walk anim
				local relativeVel
				if g_VR.input.boolean_walk then
					relativeVel = WorldToLocal((g_VR.tracking.hmd.ang:Forward()*g_VR.input.vector2_walkdirection.y + g_VR.tracking.hmd.ang:Right()*g_VR.input.vector2_walkdirection.x)*4, Angle(0,0,0), Vector(0,0,0), Angle(0,g_VR.characterYaw,0))
				else
					relativeVel = WorldToLocal(g_VR.tracking.hmd.vel, Angle(0,0,0), Vector(0,0,0), Angle(0,g_VR.characterYaw,0))
				end
				g_VR.characterWalkX = relativeVel.x*1.1
				g_VR.characterWalkY = -relativeVel.y*1.1
			end
			ply:SetPoseParameter("move_x",g_VR.net[steamid].lerpedFrame.characterWalkX)
			ply:SetPoseParameter("move_y",g_VR.net[steamid].lerpedFrame.characterWalkY)
			ply:SetPoseParameter("aim_yaw",0)
			ply:SetPoseParameter("aim_pitch",0)
			ply:SetPoseParameter("head_yaw",0)
			ply:SetPoseParameter("head_pitch",0)
			ply:SetEyeTarget(g_VR.net[steamid].lerpedFrame.hmdPos + Angle(0,g_VR.net[steamid].lerpedFrame.characterYaw,0):Forward()*30)
			--mouth animation
			local flexes = {
				ply:GetFlexIDByName( "jaw_drop" ),
				ply:GetFlexIDByName( "left_part" ),
				ply:GetFlexIDByName( "right_part" ),
				ply:GetFlexIDByName( "left_mouth_drop" ),
				ply:GetFlexIDByName( "right_mouth_drop" )
			}
			local weight = ply:IsSpeaking() && math.Clamp( ply:VoiceVolume() * 2, 0, 2 ) || 0
			for k, v in pairs( flexes ) do
				ply:SetFlexWeight( v, weight )
			end
			return false
		end )
		
		hook.Add( "CalcMainActivity" , "vrutil_hook_calcmainactivity" , function( ply , vel )
			local steamid = ply:SteamID()
			if not g_VR.net[steamid] or not g_VR.net[steamid].lerpedFrame or ply:InVehicle() then return end
			return ACT_INVALID, ply:LookupSequence("walk_all")
		end )
		
		hook.Add( "DoAnimationEvent" , "vrutil_hook_doanimationevent" , function( ply , evt, data )
			local steamid = ply:SteamID()
			if not g_VR.net[steamid] or not g_VR.net[steamid].lerpedFrame then return end
			return ACT_INVALID
		end )
		
	end
	
	function VRUtilCharacterCleanup(steamid)
		local ply = player.GetBySteamID(steamid)
		if g_VR.characterInfo[steamid] then
			if IsValid(ply) then
				for k,v in pairs(g_VR.characterInfo[steamid].bones) do
					if not isnumber(v) then continue end
					ply:ManipulateBoneAngles( v, Angle(0,0,0))
				end
				ply:RemoveCallback("BuildBonePositions",g_VR.characterInfo[steamid].boneCallback)
				ply:DisableMatrix("RenderMultiply")
			end
			g_VR.characterInfo[steamid] = nil
		end
		if ply == LocalPlayer() then
			hook.Remove( "ShouldDrawLocalPlayer" , "vrutil_hook_cshoulddrawlocalplayer")
			hook.Remove( "Think", "vrutil_hook_calcplyrenderpos")
			ply:ManipulateBoneScale(ply:LookupBone("ValveBiped.Bip01_Head1"), Vector(1,1,1))
		end
		if table.Count(g_VR.characterInfo) == 0 then
			hook.Remove("PrePlayerDraw","vrutil_hook_preplayerdraw")
			hook.Remove("PostPlayerDraw","vrutil_hook_postplayerdraw")
			hook.Remove( "UpdateAnimation" , "vrutil_hook_updateanimation")
			hook.Remove( "CalcMainActivity" , "vrutil_hook_calcmainactivity")
			hook.Remove( "DoAnimationEvent" , "vrutil_hook_doanimationevent")
		end
	end
	
end


